This is a very large request. To keep quality high and ship things you can actually use today, I'd like to do it in phases. Phase 1 are pure frontend tweaks I can finish right now. Phase 2 needs Lovable Cloud + several paid third-party services and will take multiple turns.

## Phase 1 — Frontend polish (this turn, no backend)

1. **Hero (KV) fully visible** — reduce hero min-height + tighten paragraph so on 889×581 viewport every line, stat, and CTA is visible without scrolling. Change the "Call to order" CTA in the hero to **"Explore menu"** linking to `/menu`.
2. **Add-to-cart no longer opens drawer** — `cart.add()` will stop setting `drawerOpen: true`. A small toast ("Added to cart") will confirm instead. Cart only opens when user clicks the cart icon.
3. **Fuzzy + first-letter + category search on /menu** — replace current `includes()` match with a token-based fuzzy match (matches any item OR category whose name starts with / contains the typed letters, including category name matches that surface the whole category).
4. **Menu page tabs: "Menu" | "Gallery"** — add a Gallery tab next to Menu showing:
   - Responsive square grid: 2 / 3 / 4 / 5 cols at the specified breakpoints
   - Category sections with title + 48px spacing
   - **Desktop:** hover → image scales to ~85vw with name/price/desc overlay in corner; only one expanded at a time
   - **Mobile/tablet:** tap → lightbox modal at 90% screen, dark overlay, close via X / outside / Esc / swipe down, prev/next swipe & arrows within the same category
5. **Checkout copy/UX fixes**
   - "Full name" → **"Name"** with helper "Use your bank account name for easier identification"
   - Mark required fields with a subtle `*` and helper text
   - Phone validated as Nigerian only (`07XXXXXXXXX` or `+234XXXXXXXXX`)
   - **Email required** (already is, but I'll make the asterisk visible)
   - Address only shows + required when **Delivery** selected
   - When **Pickup** is chosen, show restaurant address (Oshodi HQ) inline
   - Delivery time field only shows for Delivery, stays optional
   - Notes field stays optional
6. **Operating hours gating** — between 9am–7pm Lagos time:
   - Outside those hours: delivery option disabled with a subtle "Delivery resumes at 9am" notice
   - "Order on Glovo/Chowdeck/Online" buttons disabled with the same style notice
   - Hours displayed prominently in header strip + footer
7. **Footer** — add subtle YouTube + TikTok icons (smaller than IG/FB), add WhatsApp link, add © 2026 line, link Privacy Policy / Terms of Service.
8. **Privacy Policy + Terms of Service** static routes with the sections you listed.

## Phase 2 — Backend, admin panel, payments, comms (separate turn, requires your approvals)

This needs **Lovable Cloud** turned on, then a long list of secrets and third-party accounts. I'll do it in sub-phases so you can test each:

- **2a. Cloud + DB schema** — all tables you listed (orders, branches, delivery_settings, admin_settings, admin_sessions, ip_allowlist, admin_audit_log, admin_rate_limits, suspicious_activities, login_attempts, contact_messages) with RLS scoped to `maroluv755@gmail.com`. Seed Oshodi HQ branch.
- **2b. Admin auth** — only `maroluv755@gmail.com` can sign up/log in (enforced server-side); login at `/admin/login`, dashboard at `/admin`. Email + password + 2FA (TOTP via `otpauth` lib), backup codes, session table with 15-min idle / 8-hr absolute timeout, single active session.
- **2c. Order pipeline** — Paystack webhook + NOWPayments status poll **write the order to DB only after payment is verified**. Admin receives a copy of every order at `maroluv755@gmail.com`. Order tracking page at `/track/:orderNumber` (responsive).
- **2d. Admin dashboard** — orders list w/ filters, status updater (pending → preparing → ready → picked_up/delivered), revenue metrics (daily/weekly/monthly/quarterly/yearly/custom), AOV, top 5 items, delivery vs pickup ratio, delivery toggle, free-gift toggle (₦15k+), settings.
- **2e. Security suite** — IP allowlist, login alerts (email), audit log (immutable), rate limiting, CSRF tokens, security headers middleware, suspicious activity detection, account recovery via `maroluv755@gmail.com` or `taylorgrittdi@gmail.com` (recovery history retained forever).
- **2f. Free-gift logic** — auto-attached to orders ≥ ₦15,000 when toggle is on.
- **2g. Comms** — Resend for admin email + order confirmation email; SMS + voice via Termii (needs Termii account & key); late-pickup auto voice call 15min after `ready`.
- **2h. Smart delivery** — geocode via Google Maps, pick closest active branch, compute fee tier from `delivery_settings`. (Only one branch today, so this just validates address & computes distance/fee.)

### Secrets I'll need from you in Phase 2
`PAYSTACK_SECRET_KEY`, `PAYSTACK_WEBHOOK_SECRET`, `NOWPAYMENTS_API_KEY`, `RESEND_API_KEY`, `TERMII_API_KEY` (SMS + voice), `GOOGLE_MAPS_API_KEY`. The rest (`SUPABASE_*`, session timeouts, alert email, 2FA issuer, rate limits, suspicious-hours) I'll set as config or use sensible defaults.

### Technical notes (for me)
- Use `cmd-k` style fuzzy via tiny custom scorer (no extra dep) — match if every typed char appears in order in `item.name` OR `category.name`; bonus weight for prefix match. Surface full category if its name matches.
- Gallery: framer-motion for hover scale + AnimatePresence modal; use existing category hero images as placeholders until real photos are added.
- Hours gate: small `useNigeriaHours()` hook returning `{ deliveryOpen, opensAt }` from `Africa/Lagos` time.
- 2FA: `otpauth` (pure JS, Worker-safe).
- Single-session enforcement: on login, mark all other sessions for the admin inactive.
- Voice late-pickup: pg_cron job hits internal `/api/public/cron/late-pickup` with HMAC.

## What I need from you to proceed
1. **Confirm Phase 1 scope** — anything to add/remove?
2. **Approve enabling Lovable Cloud** for Phase 2 (I won't enable it without your OK).
3. **Confirm Termii** for SMS + voice (most common Nigeria-friendly option), or name your preferred provider.

If you reply "go", I'll start with Phase 1 immediately and queue Phase 2 right after.