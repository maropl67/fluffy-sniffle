import { Link } from "@tanstack/react-router";
import { Minus, Plus, ShoppingBag, Trash2, X } from "lucide-react";
import { useCart } from "@/lib/cart";
import { NGN } from "@/lib/format";

export function CartDrawer() {
  const { drawerOpen, setDrawer, lines, setQty, remove, subtotal } = useCart();
  const total = subtotal();

  return (
    <>
      <div
        className={`fixed inset-0 z-50 bg-charcoal/60 backdrop-blur-sm transition-opacity ${
          drawerOpen ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onClick={() => setDrawer(false)}
      />
      <aside
        className={`fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col bg-background shadow-2xl transition-transform ${
          drawerOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <header className="flex items-center justify-between border-b border-border px-5 py-4">
          <div className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-primary" />
            <h2 className="font-display text-xl text-primary">Your Cart</h2>
          </div>
          <button onClick={() => setDrawer(false)} className="rounded-full p-1.5 hover:bg-muted">
            <X className="h-5 w-5" />
          </button>
        </header>

        {lines.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
            <div className="grid h-20 w-20 place-items-center rounded-full bg-secondary text-primary">
              <ShoppingBag className="h-8 w-8" />
            </div>
            <p className="mt-4 font-display text-lg">Your cart is empty</p>
            <p className="mt-1 text-sm text-muted-foreground">Add some smokey jollof to get started 🥘</p>
            <Link
              to="/menu"
              onClick={() => setDrawer(false)}
              className="mt-6 rounded-full bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
            >
              Browse menu
            </Link>
          </div>
        ) : (
          <>
            <ul className="flex-1 divide-y divide-border overflow-y-auto px-5">
              {lines.map((l) => (
                <li key={l.id} className="flex gap-3 py-4">
                  <img src={l.image} alt="" className="h-14 w-14 rounded-lg object-cover" />
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="text-sm font-semibold">{l.name}</div>
                        {l.size && <div className="text-xs text-muted-foreground">{l.size}</div>}
                      </div>
                      <button onClick={() => remove(l.id)} className="text-muted-foreground hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <div className="inline-flex items-center rounded-full border border-border">
                        <button onClick={() => setQty(l.id, l.qty - 1)} className="px-2.5 py-1 hover:text-accent">
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="min-w-7 text-center text-sm font-semibold">{l.qty}</span>
                        <button onClick={() => setQty(l.id, l.qty + 1)} className="px-2.5 py-1 hover:text-accent">
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <div className="text-sm font-bold text-primary">{NGN(l.unitPrice * l.qty)}</div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            <footer className="border-t border-border bg-secondary/40 px-5 py-4">
              <div className="flex items-baseline justify-between">
                <span className="text-sm text-muted-foreground">Subtotal</span>
                <span className="font-display text-2xl text-primary">{NGN(total)}</span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">Delivery fee calculated at checkout.</p>
              <Link
                to="/checkout"
                onClick={() => setDrawer(false)}
                className="mt-4 grid place-items-center rounded-full bg-accent py-3 text-sm font-bold text-accent-foreground shadow-warm transition hover:bg-accent/90"
              >
                Checkout • {NGN(total)}
              </Link>
            </footer>
          </>
        )}
      </aside>
    </>
  );
}
