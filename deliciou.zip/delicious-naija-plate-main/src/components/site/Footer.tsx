import { Link } from "@tanstack/react-router";
import { Instagram, Facebook, Phone, MapPin, Clock, Youtube, MessageCircle } from "lucide-react";

function TikTokIcon({ className = "h-3.5 w-3.5" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M16.5 3a5.5 5.5 0 0 0 4.5 4.5v3a8.5 8.5 0 0 1-4.5-1.3v6.55A6.25 6.25 0 1 1 10 9.5v3.25a3 3 0 1 0 3 3V3h3.5z" />
    </svg>
  );
}

export function Footer() {
  return (
    <footer className="mt-24 bg-charcoal text-cream">
      <div className="mx-auto grid max-w-7xl gap-10 px-6 py-16 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="font-display text-2xl text-gold">Deliciousness Naija Catering</div>
          <p className="mt-3 max-w-md text-sm text-cream/70">
            Freshly made Nigerian delicacies — from smokey jollof to native soups,
            cooked with passion and served with love across Lagos.
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <a href="https://instagram.com/deliciousnessnaijacatering" target="_blank" rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-cream/20 px-4 py-2 text-xs hover:border-gold hover:text-gold">
              <Instagram className="h-4 w-4" /> 476.6K+ on Instagram
            </a>
            <a href="https://facebook.com/DeliciousnessNaijaCatering" target="_blank" rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-cream/20 px-4 py-2 text-xs hover:border-gold hover:text-gold">
              <Facebook className="h-4 w-4" /> 299.3K+ on Facebook
            </a>
            <a href="https://wa.me/2348120633599" target="_blank" rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-cream/20 px-4 py-2 text-xs hover:border-gold hover:text-gold">
              <MessageCircle className="h-4 w-4" /> WhatsApp
            </a>
            <a href="https://youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube"
              className="inline-flex h-7 w-7 items-center justify-center rounded-full border border-cream/15 text-cream/55 transition hover:border-gold hover:text-gold">
              <Youtube className="h-3.5 w-3.5" />
            </a>
            <a href="https://tiktok.com" target="_blank" rel="noreferrer" aria-label="TikTok"
              className="inline-flex h-7 w-7 items-center justify-center rounded-full border border-cream/15 text-cream/55 transition hover:border-gold hover:text-gold">
              <TikTokIcon />
            </a>
          </div>
        </div>

        <div>
          <div className="mb-3 text-xs uppercase tracking-[0.2em] text-gold/80">Visit</div>
          <p className="flex items-start gap-2 text-sm text-cream/80">
            <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
            Ilasan, 30 Silverbird Rd, Eti-Osa, Lekki 105102, Lagos
          </p>
          <p className="mt-3 flex items-center gap-2 text-sm text-cream/80">
            <Phone className="h-4 w-4 text-gold" />
            <a href="tel:+2348120633599" className="hover:text-gold">0812 063 3599</a>
          </p>
        </div>

        <div>
          <div className="mb-3 text-xs uppercase tracking-[0.2em] text-gold/80">Hours</div>
          <ul className="space-y-1 text-sm text-cream/80">
            <li className="flex items-start gap-2"><Clock className="mt-0.5 h-4 w-4 text-gold" /><span>Delivery: 9am – 7pm daily</span></li>
            <li className="pl-6">Sun 9am – 4pm · Mon–Sat 9am – 6pm</li>
          </ul>
          <div className="mt-4 flex flex-col gap-1 text-sm">
            <Link to="/menu" className="text-cream/80 hover:text-gold">Browse menu</Link>
            <Link to="/checkout" className="text-cream/80 hover:text-gold">Checkout</Link>
          </div>
        </div>
      </div>
      <div className="border-t border-cream/10 py-5 text-center text-xs text-cream/50">
        © 2026 Deliciousness Naija Catering. All rights reserved. ·{" "}
        <Link to="/privacy" className="hover:text-gold">Privacy Policy</Link> ·{" "}
        <Link to="/terms" className="hover:text-gold">Terms of Service</Link>
      </div>
    </footer>
  );
}
