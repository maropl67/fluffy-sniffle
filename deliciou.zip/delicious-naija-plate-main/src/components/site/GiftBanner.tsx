import { Gift } from "lucide-react";
import { usePublicSettings } from "@/lib/use-settings";
import { NGN } from "@/lib/format";

export function GiftBanner({ className = "" }: { className?: string }) {
  const { data } = usePublicSettings();
  const g = data?.freeGift;
  if (!g?.enabled) return null;
  return (
    <div className={`flex items-start gap-3 rounded-2xl border border-gold/30 bg-gold/10 px-4 py-3 text-sm text-charcoal ${className}`}>
      <Gift className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
      <div>
        <div className="font-semibold">Free gift on orders of {NGN(g.threshold_kobo / 100)} and above</div>
        <div className="text-xs text-muted-foreground">{g.item_name} — {g.item_note}</div>
      </div>
    </div>
  );
}
