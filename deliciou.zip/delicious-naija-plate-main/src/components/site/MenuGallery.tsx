import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { CATEGORIES, type MenuItem } from "@/data/menu";
import { NGN } from "@/lib/format";

type Flat = { item: MenuItem; categoryId: string; categoryName: string; price: number };

function priceOf(i: MenuItem) {
  return i.price ?? i.sizes?.[0]?.price ?? 0;
}

export function MenuGallery() {
  const [openIdx, setOpenIdx] = useState<{ cat: string; idx: number } | null>(null);
  const [hoverKey, setHoverKey] = useState<string | null>(null);

  // Close on Escape, prev/next on arrow keys
  useEffect(() => {
    if (!openIdx) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpenIdx(null);
      if (e.key === "ArrowRight") nav(1);
      if (e.key === "ArrowLeft") nav(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [openIdx]);

  const flatByCat = useMemo(() => {
    const map: Record<string, Flat[]> = {};
    for (const c of CATEGORIES) {
      map[c.id] = c.items.map((item) => ({
        item, categoryId: c.id, categoryName: c.name, price: priceOf(item),
      }));
    }
    return map;
  }, []);

  function nav(delta: number) {
    setOpenIdx((prev) => {
      if (!prev) return prev;
      const list = flatByCat[prev.cat];
      const next = (prev.idx + delta + list.length) % list.length;
      return { cat: prev.cat, idx: next };
    });
  }

  const current = openIdx ? flatByCat[openIdx.cat][openIdx.idx] : null;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      {CATEGORIES.map((c) => (
        <section key={c.id} id={`gallery-${c.id}`} className="mb-12 scroll-mt-36">
          <header className="mb-4">
            <h2 className="font-display text-2xl text-primary sm:text-3xl">{c.name}</h2>
            <p className="text-xs text-muted-foreground">{c.items.length} items</p>
          </header>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 sm:gap-3 lg:grid-cols-4 xl:grid-cols-5">
            {c.items.map((item, idx) => {
              const key = `${c.id}-${item.id}`;
              const isHover = hoverKey === key;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setOpenIdx({ cat: c.id, idx })}
                  onMouseEnter={() => setHoverKey(key)}
                  onMouseLeave={() => setHoverKey((k) => (k === key ? null : k))}
                  className="group relative aspect-square overflow-hidden rounded-xl bg-secondary text-left shadow-soft transition hover:shadow-warm focus:outline-none focus-visible:ring-2 focus-visible:ring-accent"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    loading="lazy"
                    className="absolute inset-0 h-full w-full object-cover transition duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-charcoal/85 via-charcoal/10 to-transparent" />
                  <div className="absolute inset-x-2 bottom-2 text-cream">
                    <div className="line-clamp-1 text-[11px] font-semibold sm:text-xs">{item.name}</div>
                    <div className="text-[10px] font-bold text-gold sm:text-[11px]">{NGN(priceOf(item))}</div>
                  </div>

                  {/* Desktop hover preview */}
                  <AnimatePresence>
                    {isHover && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="pointer-events-none fixed inset-0 z-40 hidden place-items-center bg-charcoal/85 backdrop-blur-sm md:grid"
                      >
                        <motion.div
                          layoutId={`gallery-${key}`}
                          className="relative h-[85vh] w-[85vw] max-w-5xl overflow-hidden rounded-3xl"
                        >
                          <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                          <div className="absolute bottom-6 left-6 max-w-md rounded-2xl bg-charcoal/75 p-5 text-cream backdrop-blur">
                            <div className="font-display text-3xl">{item.name}</div>
                            <div className="mt-1 font-display text-xl text-gold">{NGN(priceOf(item))}</div>
                            <p className="mt-2 text-sm text-cream/85">{item.desc}</p>
                          </div>
                        </motion.div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </button>
              );
            })}
          </div>
        </section>
      ))}

      {/* Mobile / tap modal */}
      <AnimatePresence>
        {current && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 grid place-items-center bg-charcoal/85 backdrop-blur"
            onClick={() => setOpenIdx(null)}
          >
            <button
              onClick={(e) => { e.stopPropagation(); setOpenIdx(null); }}
              className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full bg-cream/15 text-cream hover:bg-cream/25"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); nav(-1); }}
              className="absolute left-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-cream/15 text-cream hover:bg-cream/25"
              aria-label="Previous"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); nav(1); }}
              className="absolute right-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-cream/15 text-cream hover:bg-cream/25"
              aria-label="Next"
            >
              <ChevronRight className="h-5 w-5" />
            </button>

            <motion.div
              key={current.item.id}
              drag="y"
              dragConstraints={{ top: 0, bottom: 0 }}
              dragElastic={0.4}
              onDragEnd={(_, info) => {
                if (info.offset.y > 120) setOpenIdx(null);
              }}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="relative h-[90vh] w-[90vw] max-w-3xl overflow-hidden rounded-3xl"
              onClick={(e) => e.stopPropagation()}
            >
              <img src={current.item.image} alt={current.item.name} className="h-full w-full object-cover" />
              <div className="absolute bottom-4 left-4 right-4 max-w-md rounded-2xl bg-charcoal/80 p-5 text-cream backdrop-blur sm:right-auto">
                <div className="text-[11px] uppercase tracking-widest text-gold">{current.categoryName}</div>
                <div className="mt-1 font-display text-2xl sm:text-3xl">{current.item.name}</div>
                <div className="mt-1 font-display text-lg text-gold">{NGN(current.price)}</div>
                <p className="mt-2 text-sm text-cream/85">{current.item.desc}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
