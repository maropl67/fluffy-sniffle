import { useState } from "react";
import { Plus } from "lucide-react";
import type { MenuItem } from "@/data/menu";
import { useCart } from "@/lib/cart";
import { NGN } from "@/lib/format";
import { toast } from "sonner";

export function MenuItemCard({ item }: { item: MenuItem }) {
  const add = useCart((s) => s.add);
  const [sizeIdx, setSizeIdx] = useState(0);

  const hasSizes = !!item.sizes?.length;
  const price = hasSizes ? item.sizes![sizeIdx].price : item.price ?? 0;
  const sizeLabel = hasSizes ? item.sizes![sizeIdx].label : undefined;

  const onAdd = () => {
    add({
      id: item.id + (sizeLabel ? `__${sizeLabel}` : ""),
      itemId: item.id,
      name: item.name,
      size: sizeLabel,
      unitPrice: price,
      image: item.image,
    });
    toast.success(`${item.name} added`, { description: sizeLabel ? `Size: ${sizeLabel}` : undefined });
  };

  return (
    <div className="group flex gap-3 rounded-2xl border border-border/70 bg-card p-3 transition hover:border-accent/50 hover:shadow-soft sm:p-4">
      <img
        src={item.image}
        alt={item.name}
        width={40}
        height={40}
        loading="lazy"
        className="h-10 w-10 shrink-0 rounded-lg object-cover ring-2 ring-secondary"
      />
      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-sm font-semibold leading-tight text-foreground sm:text-base">{item.name}</h3>
          <span className="shrink-0 text-sm font-bold text-primary sm:text-base">{NGN(price)}</span>
        </div>
        <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{item.desc}</p>
        {item.note && <p className="mt-1 text-[11px] font-medium text-accent">{item.note}</p>}

        <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
          {hasSizes ? (
            <div className="flex flex-wrap gap-1">
              {item.sizes!.map((s, i) => (
                <button
                  key={s.label}
                  onClick={() => setSizeIdx(i)}
                  className={`rounded-full px-2.5 py-1 text-[11px] font-medium transition ${
                    i === sizeIdx
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/70"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          ) : <span />}
          <button
            onClick={onAdd}
            className="inline-flex items-center gap-1 rounded-full bg-accent px-3 py-1.5 text-xs font-semibold text-accent-foreground transition hover:bg-accent/90 active:scale-95"
          >
            <Plus className="h-3.5 w-3.5" /> Add
          </button>
        </div>
      </div>
    </div>
  );
}
