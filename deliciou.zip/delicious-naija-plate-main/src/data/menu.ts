import rice from "@/assets/cat-rice.jpg";
import pasta from "@/assets/cat-pasta.jpg";
import sides from "@/assets/cat-sides.jpg";
import porridge from "@/assets/cat-porridge.jpg";
import smallchops from "@/assets/cat-smallchops.jpg";
import platters from "@/assets/cat-platters.jpg";
import pockets from "@/assets/cat-pockets.jpg";
import deluxe from "@/assets/cat-deluxe.jpg";
import soups from "@/assets/cat-soups.jpg";
import special from "@/assets/cat-special.jpg";
import peppersoup from "@/assets/cat-peppersoup.jpg";
import proteins from "@/assets/cat-proteins.jpg";

export type Size = { label: string; price: number };
export type MenuItem = {
  id: string;
  name: string;
  desc: string;
  price?: number;       // for single-priced items
  sizes?: Size[];       // for multi-size items (soups, peppersoups, specials)
  note?: string;
  image: string;        // category image (40x40 thumb)
};
export type Category = { id: string; name: string; image: string; items: MenuItem[] };

const id = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

// Soup/pepper-soup size price ladders (NGN)
const SOUP_SIZES = (base: number): Size[] => [
  { label: "1.5L", price: base },
  { label: "2.5L", price: Math.round(base * 1.55) },
  { label: "3.5L", price: Math.round(base * 2.1) },
  { label: "4.5L", price: Math.round(base * 2.6) },
  { label: "10L",  price: Math.round(base * 5.4) },
];
const SPECIAL_SIZES = (base: number): Size[] => [
  { label: "1.5L", price: base },
  { label: "2.5L", price: Math.round(base * 1.55) },
  { label: "3.5L", price: Math.round(base * 2.1) },
  { label: "4.5L", price: Math.round(base * 2.6) },
];

const mk = (name: string, desc: string, price: number, image: string): MenuItem =>
  ({ id: id(name), name, desc, price, image });
const mkS = (name: string, desc: string, sizes: Size[], image: string, note?: string): MenuItem =>
  ({ id: id(name), name, desc, sizes, image, note });

export const CATEGORIES: Category[] = [
  {
    id: "rice", name: "Rice", image: rice,
    items: [
      mk("Smokey Jollof Rice", "Wood-fire smokey jollof, our signature.", 5500, rice),
      mk("Nigerian Fried Rice", "Classic veg fried rice with liver & shrimp bits.", 6000, rice),
      mk("Basmati Jollof Rice", "Long-grain basmati cooked in rich tomato stew.", 7500, rice),
      mk("Basmati Fried Rice", "Aromatic basmati with mixed veg.", 8000, rice),
      mk("Special Basmati/Chinese Fried Rice", "Loaded with prawns, chicken & sausage.", 11000, rice),
      mk("White Rice", "Soft, fluffy long-grain white rice.", 4000, rice),
      mk("Ofada Rice", "Local unpolished rice (sauce sold separately).", 5500, rice, ),
      mk("Coconut Rice", "Slow-cooked in fresh coconut milk.", 6500, rice),
      mk("Native/Village Rice", "Palm-oil native rice with assorted.", 7500, rice),
      mk("Rice and Beans", "Combo of rice & honey beans (stew sold separately).", 5000, rice),
      mk("Pepper Rice", "Fiery, peppered party-style rice.", 6500, rice),
      mk("Seafood Basmati Fried Rice", "Basmati with prawns, calamari & fish.", 14000, rice),
      mk("Asun Basmati Fried Rice", "Basmati layered with peppered asun.", 13000, rice),
      mk("Asun Jollof Rice", "Smokey jollof tossed with asun.", 10000, rice),
      mk("Basmati Village Rice", "Native-style basmati with palm oil.", 9500, rice),
      mk("Seafood Basmati Village Rice", "Native basmati loaded with seafood.", 15500, rice),
      mk("Fully Loaded Basmati Village Rice", "Native basmati with full assorted protein.", 17000, rice),
      mk("Basmati Coconut Rice", "Coconut-infused basmati.", 8500, rice),
      mk("Seafood Basmati Coconut Rice", "Coconut basmati with prawns & fish.", 15000, rice),
      mk("Basmati White Rice", "Plain steamed basmati.", 6000, rice),
      mk("White Yam", "Boiled tender white yam.", 4000, rice),
    ],
  },
  {
    id: "pasta", name: "Pasta", image: pasta,
    items: [
      mk("Stirfry Penny Pasta", "Penne stir-fried with veg & spices.", 5500, pasta),
      mk("Jollof Pasta", "Spaghetti cooked jollof-style.", 5000, pasta),
      mk("Asun Pasta", "Spaghetti tossed with peppered asun.", 9500, pasta),
      mk("Seafood Pasta", "Pasta loaded with prawns & calamari.", 12000, pasta),
      mk("Village Pasta", "Native palm-oil pasta with assorted.", 7000, pasta),
      mk("Alfredo Pasta", "Creamy garlic alfredo with chicken.", 9000, pasta),
    ],
  },
  {
    id: "sides", name: "Sides", image: sides,
    items: [
      mk("Plantain (Dodo)", "Sweet ripe plantain, golden fried.", 2500, sides),
      mk("Basic Salad", "Crisp garden salad with dressing.", 3500, sides),
      mkS("Moi Moi", "Steamed bean pudding — min. 10 pieces.", [{ label: "per piece (min 10)", price: 1500 }], sides, "Minimum order: 10 pieces"),
    ],
  },
  {
    id: "porridge", name: "Porridge", image: porridge,
    items: [
      mk("Yam Porridge (Normal)", "Soft yam in palm-oil sauce.", 5500, porridge),
      mk("Yam Porridge (Fully Loaded)", "Loaded with fish, meat & veggies.", 9500, porridge),
      mk("Beans Porridge", "Honey beans in rich palm sauce.", 5000, porridge),
      mk("Plantain Porridge (Normal)", "Soft plantain pottage.", 5500, porridge),
      mk("Plantain Porridge (Fully Loaded)", "Loaded with assorted protein.", 9500, porridge),
      mk("Sweet Potato Porridge", "Slow-cooked sweet potato pottage.", 6000, porridge),
    ],
  },
  {
    id: "smallchops", name: "Protein & Small Chops Style", image: smallchops,
    items: [
      mk("Beef/Chicken Dodo", "Peppered beef or chicken with plantain.", 4500, smallchops),
      mk("Gizz Dodo", "Classic gizzard & plantain skewer.", 5000, smallchops),
      mk("Peppered Ponmo", "Soft cow-skin in scotch-bonnet sauce.", 4000, smallchops),
    ],
  },
  {
    id: "platters", name: "Combos & Platters", image: platters,
    items: [
      mk("Sexy Jollof Rice + 8 Turkey Platter", "Smokey jollof + 8 cut turkey.", 28000, platters),
      mk("Special Basmati Fried Rice + Hell Fire Turkey", "Spicy turkey with basmati.", 32000, platters),
      mk("Full Seafood Basmati Fried Rice + 5 Chicken + 5 Eggs", "Loaded seafood tray.", 55000, platters),
      mk("Tray of Jollof Rice + 10 Beef + 1.5 Plantain", "Family tray combo.", 38000, platters),
      mk("Nigerian Fried Rice + Turkey Combo", "Fried rice with cut turkey.", 18000, platters),
      mk("Tray of Stirfry Pasta + 8 Cut Turkey", "Pasta party tray.", 32000, platters),
      mk("Jollof + Beef", "Quick jollof + beef pack.", 4500, platters),
      mk("On The Go Jollof Combo", "Jollof + protein + plantain to go.", 6000, platters),
      mk("Foodlum Combo", "House combo for serious eaters.", 8500, platters),
      mk("Meaty Platter", "Assorted meats platter.", 22000, platters),
      mk("Full Goatmeat Platter", "Large peppered goat meat tray.", 65000, platters),
      mk("Full Ram Meat Platter", "Premium ram-meat tray.", 85000, platters),
      mk("Mini Ram Meat Platter", "Smaller ram-meat platter.", 45000, platters),
      mk("Chicken Platter", "Grilled / peppered chicken platter.", 28000, platters),
      mk("Beef Platter", "Tender peppered beef chunks.", 22000, platters),
      mk("Mixed Meat Platter", "Beef, chicken, gizzard combo.", 32000, platters),
      mk("Hell Fire Turkey + Yam Fries Platter", "Spicy turkey & yam fries (full).", 38000, platters),
      mk("Mini Hell Fire Turkey + Yam Fries Platter", "Mini version.", 22000, platters),
      mk("Full Prawns Platter", "Plump grilled prawns (full).", 75000, platters),
      mk("Mini Prawns Platter", "Grilled prawns (mini).", 40000, platters),
      mk("Full Snail Platter", "Jumbo snails — full tray.", 85000, platters),
      mk("Mini Snail Platter", "Jumbo snails — mini.", 45000, platters),
      mk("Sauced & Garnished Snail + Prawns Platter", "Snails + prawns in chef sauce.", 72000, platters),
      mk("Full Tray of Small Chops", "Puff, samosa, spring roll, gizzdodo, etc.", 35000, platters),
      mk("Mini Small Chops", "Mini party pack of small chops.", 12000, platters),
      mk("Extra Yam", "Add-on white yam.", 1500, platters),
      mk("Extra Sauce", "Add-on rich house sauce.", 2000, platters),
      mk("Turkey", "Single cut turkey add-on.", 4500, platters),
    ],
  },
  {
    id: "pockets", name: "Pocket Friendly Packs", image: pockets,
    items: [
      mk("Smokey Normal Jollof + Peppered Chicken + Beef + Plantain", "Loaded pocket pack.", 8500, pockets),
      mk("Special Normal Fried Rice + Turkey Fried Yam + Chicken + Sauce", "Fried rice value pack.", 9500, pockets),
      mk("Stir Fried Spaghetti + Turkey + Plantain", "Pasta turkey pack.", 7500, pockets),
      mk("Smokey Normal Jollof + Peppered Chicken + Plantain", "Quick jollof combo.", 6500, pockets),
    ],
  },
  {
    id: "deluxe", name: "Deluxe Packs", image: deluxe,
    items: [
      mk("Smokey Basmati Jollof + Chicken + Beef Kebab + Plantain", "Premium basmati pack.", 13500, deluxe),
      mk("Basmati Fried Rice + Chicken + Plantain", "Aromatic deluxe combo.", 12000, deluxe),
      mk("Seafood Basmati Jollof + Chicken + Plantain", "Seafood-loaded jollof.", 15500, deluxe),
      mk("Seafood Fried Rice + Prawns", "Fried rice with juicy prawns.", 15000, deluxe),
      mk("Shredded Chicken Stir Fried Spaghetti + Turkey + Plantain", "Chef pasta pack.", 13000, deluxe),
      mk("Stir Fried Singaporean Noodles + Turkey", "Asian-style noodles + turkey.", 12500, deluxe),
      mk("Special Ofada + Sauce + Plantain", "Ofada with smoky ayamase.", 9500, deluxe),
      mk("Ewa Agonyin + Fish Sauce + Plantain", "Mashed beans + fish sauce.", 8000, deluxe),
      mk("Linguine Special + Beef Chunks + Turkey", "Linguine with beef & turkey.", 13500, deluxe),
      mk("White Rice + Turkey + Red Ofada Sauce", "Plain rice + bold sauce.", 11000, deluxe),
      mk("Basmati Village Rice + Turkey + Chicken + Plantain", "Native basmati combo.", 14500, deluxe),
    ],
  },
  {
    id: "soups", name: "Soups & Stews", image: soups,
    items: [
      mkS("Red Stew", "Classic rich tomato pepper stew.", SOUP_SIZES(15000), soups),
      mkS("Egusi / Efo Riro", "Choose egusi or efo riro.", SOUP_SIZES(18000), soups),
      mkS("Okro Soup", "Fresh okro with palm oil.", SOUP_SIZES(17000), soups),
      mkS("Seafood Okro", "Okro loaded with seafood.", SOUP_SIZES(24000), soups),
      mkS("Afang / Edikaikong", "Choice of vegetable soup.", SOUP_SIZES(22000), soups),
      mkS("Banga / Oha / Bitterleaf", "Choose your eastern delight.", SOUP_SIZES(22000), soups),
      mkS("Ogbono / Black Soup", "Choose ogbono or black soup.", SOUP_SIZES(20000), soups),
      mkS("Ofe Nsala", "White soup, peppery & aromatic.", SOUP_SIZES(22000), soups),
      mkS("Fisherman Soup", "Seafood medley soup.", SOUP_SIZES(28000), soups),
      mkS("Atama Soup", "Native atama leaf soup.", SOUP_SIZES(23000), soups),
      mkS("Ofe Owerri", "Premium Owerri-style soup.", SOUP_SIZES(28000), soups),
      mkS("Ofe Akwu", "Palm-fruit banga sauce.", SOUP_SIZES(20000), soups),
      mkS("Red/Green Ofada Sauce", "Smoky ayamase, red or green.", SOUP_SIZES(18000), soups),
      mkS("Mackerel Fish Sauce", "Rich titus mackerel sauce.", SOUP_SIZES(18000), soups),
      mkS("Paradise / Ata Dindin Sauce", "Fried pepper sauce.", SOUP_SIZES(17000), soups),
      mkS("Fried Egg Sauce", "Bold tomato-pepper egg sauce.", SOUP_SIZES(15000), soups),
      mkS("Meatball Sauce", "Tender meatballs in chef sauce.", SOUP_SIZES(20000), soups),
      mkS("Sweet & Sour Chicken Sauce", "Asian-style chicken sauce.", SOUP_SIZES(22000), soups),
      mkS("Seafood Thai Curry Sauce", "Coconut-curry seafood sauce.", SOUP_SIZES(28000), soups),
    ],
  },
  {
    id: "special", name: "Special Delicacies", image: special,
    items: [
      mkS("Nkwobi", "Spicy cow-foot in utazi & palm oil.", SPECIAL_SIZES(22000), special),
      mkS("Isi Ewu", "Goat-head delicacy, peppered.", SPECIAL_SIZES(28000), special),
      mkS("Asun", "Smoky peppered goat-meat asun.", SPECIAL_SIZES(25000), special),
    ],
  },
  {
    id: "peppersoup", name: "Pepper Soup", image: peppersoup,
    items: [
      mkS("Live Chicken Peppersoup", "Native live-chicken peppersoup.", SOUP_SIZES(20000), peppersoup),
      mkS("Goat Meat Peppersoup", "Tender goat peppersoup.", SOUP_SIZES(22000), peppersoup),
      mkS("Catfish Peppersoup", "Fresh catfish point-and-kill.", SOUP_SIZES(22000), peppersoup),
      mkS("Chicken Peppersoup", "Classic chicken peppersoup.", SOUP_SIZES(18000), peppersoup),
      mkS("Cowleg Peppersoup", "Rich cow-leg peppersoup.", SOUP_SIZES(20000), peppersoup),
      mkS("Turkey Peppersoup", "Peppery turkey wing soup.", SOUP_SIZES(22000), peppersoup),
    ],
  },
  {
    id: "proteins", name: "Proteins (À la carte)", image: proteins,
    items: [
      mk("Beef", "Single peppered beef portion.", 2500, proteins),
      mk("Goat Meat", "Tender peppered goat-meat.", 4500, proteins),
      mk("Ram Meat", "Premium ram-meat cut.", 6000, proteins),
      mk("Chicken", "Peppered chicken portion.", 3500, proteins),
      mk("Big Turkey", "Large grilled turkey cut.", 6000, proteins),
      mk("Medium Turkey", "Medium turkey cut.", 4500, proteins),
      mk("Cowleg", "Soft seasoned cow-leg.", 4500, proteins),
      mk("Assorted", "Mix of offals & meat.", 4000, proteins),
      mk("Gizzard", "Peppered gizzard.", 3500, proteins),
      mk("Jumbo Snail", "One jumbo grilled snail.", 8000, proteins),
      mk("Prawns", "Plump grilled prawns.", 9000, proteins),
      mk("Croaker", "Fresh croaker fish.", 8500, proteins),
      mk("Titus Fish", "Grilled titus mackerel.", 5500, proteins),
      mk("Hake Fish", "Lightly seasoned hake.", 5000, proteins),
      mk("Stewed Catfish", "Catfish in rich stew.", 7500, proteins),
      mk("Fried Catfish", "Crispy fried catfish.", 7500, proteins),
    ],
  },
];

export const findItem = (itemId: string) =>
  CATEGORIES.flatMap(c => c.items).find(i => i.id === itemId);
