import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireAdmin } from "@/integrations/supabase/admin-guard";

export const adminListOrders = createServerFn({ method: "GET" })
  .middleware([requireAdmin])
  .handler(async ({ context }) => {
    const { supabase } = context as any;
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(500);
    if (error) throw new Error(error.message);
    return { orders: data ?? [] };
  });

export const adminUpdateOrderStatus = createServerFn({ method: "POST" })
  .middleware([requireAdmin])
  .inputValidator((d) => z.object({
    id: z.string().uuid(),
    status: z.enum(["pending_payment", "paid", "preparing", "out_for_delivery", "ready_for_pickup", "completed", "cancelled", "refunded"]),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    const { error } = await supabase.from("orders").update({ status: data.status }).eq("id", data.id);
    if (error) throw new Error(error.message);
    await supabase.from("audit_logs").insert({
      actor_id: userId,
      action: "order.status.update",
      target_type: "order", target_id: data.id,
      metadata: { status: data.status },
    });
    return { ok: true };
  });

export const adminGetSettings = createServerFn({ method: "GET" })
  .middleware([requireAdmin])
  .handler(async ({ context }) => {
    const { supabase } = context as any;
    const { data, error } = await supabase.from("admin_settings").select("key,value");
    if (error) throw new Error(error.message);
    return { settings: Object.fromEntries((data ?? []).map((r: any) => [r.key, r.value])) };
  });

export const adminUpdateSetting = createServerFn({ method: "POST" })
  .middleware([requireAdmin])
  .inputValidator((d) => z.object({ key: z.string().min(1).max(64), value: z.any() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as any;
    const { error } = await supabase
      .from("admin_settings")
      .upsert({ key: data.key, value: data.value, updated_by: userId, updated_at: new Date().toISOString() });
    if (error) throw new Error(error.message);
    await supabase.from("audit_logs").insert({
      actor_id: userId,
      action: "settings.update",
      target_type: "admin_settings", target_id: data.key,
      metadata: { value: data.value },
    });
    return { ok: true };
  });

export const adminListAudit = createServerFn({ method: "GET" })
  .middleware([requireAdmin])
  .handler(async ({ context }) => {
    const { supabase } = context as any;
    const { data, error } = await supabase
      .from("audit_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    return { entries: data ?? [] };
  });

export const adminCheckRole = createServerFn({ method: "GET" })
  .middleware([requireAdmin])
  .handler(async ({ context }) => {
    return { userId: (context as any).userId, admin: true };
  });

export const adminAnalytics = createServerFn({ method: "POST" })
  .middleware([requireAdmin])
  .inputValidator((d) => z.object({
    from: z.string(),
    to: z.string(),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context as any;
    const from = new Date(data.from);
    const to = new Date(data.to);
    const { data: rows, error } = await supabase
      .from("orders")
      .select("id,total_kobo,subtotal_kobo,fulfillment,items,status,created_at,user_id")
      .gte("created_at", from.toISOString())
      .lte("created_at", to.toISOString())
      .in("status", ["paid", "preparing", "out_for_delivery", "ready_for_pickup", "completed"]);
    if (error) throw new Error(error.message);
    const orders = rows ?? [];
    const totalRevenue = orders.reduce((s: number, o: any) => s + (o.total_kobo ?? 0), 0);
    const count = orders.length;
    const aov = count ? Math.round(totalRevenue / count) : 0;
    const days = Math.max(1, Math.ceil((to.getTime() - from.getTime()) / 86_400_000));
    const ordersPerDay = +(count / days).toFixed(2);
    const delivery = orders.filter((o: any) => o.fulfillment === "delivery").length;
    const pickup = count - delivery;
    // Top 5 items
    const itemCounts = new Map<string, { name: string; qty: number; revenue: number }>();
    for (const o of orders as any[]) {
      const items = Array.isArray(o.items) ? o.items : [];
      for (const it of items) {
        const name = it?.name || it?.title || "Unknown";
        const qty = Number(it?.qty ?? it?.quantity ?? 1);
        const price = Number(it?.price_kobo ?? (it?.price ? it.price * 100 : 0));
        const cur = itemCounts.get(name) ?? { name, qty: 0, revenue: 0 };
        cur.qty += qty;
        cur.revenue += price * qty;
        itemCounts.set(name, cur);
      }
    }
    const topItems = Array.from(itemCounts.values()).sort((a, b) => b.qty - a.qty).slice(0, 5);
    // Customer acquisition: new users in window with at least one order
    const uniqueUsers = new Set(orders.map((o: any) => o.user_id).filter(Boolean));
    const newCustomers = uniqueUsers.size;
    const cac = newCustomers ? Math.round(totalRevenue / newCustomers) : 0; // proxy
    // Daily series
    const dayMap = new Map<string, number>();
    for (const o of orders as any[]) {
      const d = new Date(o.created_at).toISOString().slice(0, 10);
      dayMap.set(d, (dayMap.get(d) ?? 0) + (o.total_kobo ?? 0));
    }
    const series = Array.from(dayMap.entries()).sort().map(([day, kobo]) => ({ day, kobo }));
    return {
      totalRevenue, count, aov, ordersPerDay,
      deliveryCount: delivery, pickupCount: pickup,
      topItems, newCustomers, cac, series,
    };
  });
