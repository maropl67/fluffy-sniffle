import { create } from "zustand";
import { persist } from "zustand/middleware";

export type CartLine = {
  id: string;         // unique line id (itemId + size)
  itemId: string;
  name: string;
  size?: string;
  unitPrice: number;
  qty: number;
  image: string;
};

type CartState = {
  lines: CartLine[];
  drawerOpen: boolean;
  setDrawer: (v: boolean) => void;
  add: (line: Omit<CartLine, "qty">, qty?: number) => void;
  remove: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
  subtotal: () => number;
  count: () => number;
};

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      lines: [],
      drawerOpen: false,
      setDrawer: (v) => set({ drawerOpen: v }),
      add: (line, qty = 1) =>
        set((s) => {
          const existing = s.lines.find((l) => l.id === line.id);
          if (existing) {
            return {
              lines: s.lines.map((l) =>
                l.id === line.id ? { ...l, qty: l.qty + qty } : l,
              ),
            };
          }
          return { lines: [...s.lines, { ...line, qty }] };
        }),
      remove: (id) =>
        set((s) => ({ lines: s.lines.filter((l) => l.id !== id) })),
      setQty: (id, qty) =>
        set((s) => ({
          lines: s.lines
            .map((l) => (l.id === id ? { ...l, qty: Math.max(1, qty) } : l))
            .filter((l) => l.qty > 0),
        })),
      clear: () => set({ lines: [] }),
      subtotal: () =>
        get().lines.reduce((sum, l) => sum + l.unitPrice * l.qty, 0),
      count: () => get().lines.reduce((n, l) => n + l.qty, 0),
    }),
    { name: "dn-cart-v1" },
  ),
);
