import type { FreeGiftSetting } from "./settings.functions";

export type GiftEligibility = {
  eligible: boolean;
  remainingKobo: number;
  thresholdKobo: number;
  itemName: string;
  note: string;
};

export function evaluateGift(subtotalNaira: number, setting?: FreeGiftSetting): GiftEligibility | null {
  if (!setting?.enabled) return null;
  const subtotalKobo = Math.round(subtotalNaira * 100);
  const eligible = subtotalKobo >= setting.threshold_kobo;
  return {
    eligible,
    remainingKobo: Math.max(0, setting.threshold_kobo - subtotalKobo),
    thresholdKobo: setting.threshold_kobo,
    itemName: setting.item_name,
    note: setting.item_note,
  };
}
