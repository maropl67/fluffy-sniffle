// Lightweight fuzzy matcher for menu search.
// Matches if every typed char appears in order in the haystack (case-insensitive).
// Returns a score (lower = better). Returns null when no match.

export function fuzzyScore(query: string, target: string): number | null {
  if (!query) return 0;
  const q = query.toLowerCase().trim();
  const t = target.toLowerCase();
  if (!q) return 0;

  // Strong bonuses
  if (t.startsWith(q)) return -1000 + (t.length - q.length);
  const wordPrefix = t.split(/[\s\-/&,()]+/).some((w) => w.startsWith(q));
  if (wordPrefix) return -500 + (t.length - q.length);
  if (t.includes(q)) return -100 + (t.length - q.length);

  // Subsequence match
  let ti = 0;
  let lastIdx = -1;
  let gaps = 0;
  for (let qi = 0; qi < q.length; qi++) {
    const c = q[qi];
    const found = t.indexOf(c, ti);
    if (found === -1) return null;
    if (lastIdx !== -1) gaps += found - lastIdx - 1;
    lastIdx = found;
    ti = found + 1;
  }
  return gaps + t.length;
}
