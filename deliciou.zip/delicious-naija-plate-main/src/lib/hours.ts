// Restaurant operating + delivery hours, computed in Africa/Lagos (UTC+1, no DST).
// Delivery window: 9am – 7pm daily.

import { useEffect, useState } from "react";

export const DELIVERY_OPEN_HOUR = 9;
export const DELIVERY_CLOSE_HOUR = 19;

function lagosHour(now = new Date()): number {
  // Lagos is fixed UTC+1 year-round.
  const utcMinutes = now.getUTCHours() * 60 + now.getUTCMinutes();
  return Math.floor(((utcMinutes + 60) % (24 * 60)) / 60);
}

export function isDeliveryOpen(now = new Date()): boolean {
  const h = lagosHour(now);
  return h >= DELIVERY_OPEN_HOUR && h < DELIVERY_CLOSE_HOUR;
}

export function deliveryStatusText(now = new Date()): string {
  return isDeliveryOpen(now)
    ? `Delivery open · until ${DELIVERY_CLOSE_HOUR > 12 ? DELIVERY_CLOSE_HOUR - 12 : DELIVERY_CLOSE_HOUR}pm`
    : `Delivery resumes at ${DELIVERY_OPEN_HOUR}am (Lagos time)`;
}

export function useNigeriaHours() {
  const [open, setOpen] = useState(() => isDeliveryOpen());
  useEffect(() => {
    const id = setInterval(() => setOpen(isDeliveryOpen()), 60 * 1000);
    return () => clearInterval(id);
  }, []);
  return { deliveryOpen: open, status: deliveryStatusText() };
}

export const RESTAURANT_ADDRESS = "Ilasan, 30 Silverbird Rd, Eti-Osa, Lekki 105102, Lagos";
