// Server-only helpers for orders. Never import from client code.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { getPublicSettings } from "./settings.functions";
import { evaluateGift } from "./free-gift";

export type OrderInput = {
  customer: {
    name: string;
    phone: string;
    email: string;
    fulfilment: "delivery" | "pickup";
    address?: string;
    notes?: string;
  };
  items: Array<{ id: string; itemId: string; name: string; size?: string; unitPrice: number; qty: number }>;
  subtotal: number;
  deliveryFee: number;
  total: number;
  userId?: string | null;
};

export async function createPendingOrder(input: OrderInput) {
  const settings = await getPublicSettings();
  const gift = evaluateGift(input.subtotal, settings.freeGift);
  const freeGiftApplied = !!gift?.eligible;

  const itemsForDb = input.items.map((l) => ({
    item_id: l.itemId, name: l.name, size: l.size ?? null, unit_price: l.unitPrice, qty: l.qty,
  }));

  const { data, error } = await supabaseAdmin
    .from("orders")
    .insert({
      user_id: input.userId ?? null,
      customer_name: input.customer.name,
      customer_phone: input.customer.phone,
      customer_email: input.customer.email,
      fulfillment: input.customer.fulfilment,
      delivery_address: input.customer.fulfilment === "delivery" ? input.customer.address ?? null : null,
      delivery_fee_kobo: Math.round(input.deliveryFee * 100),
      subtotal_kobo: Math.round(input.subtotal * 100),
      total_kobo: Math.round(input.total * 100),
      items: itemsForDb,
      free_gift_applied: freeGiftApplied,
      free_gift_item: freeGiftApplied ? { name: gift!.itemName, note: gift!.note } : null,
      notes: input.customer.notes ?? null,
      status: "pending_payment",
    })
    .select("id, order_number")
    .single();

  if (error || !data) throw new Error(error?.message || "Could not create order");
  return data;
}

export async function recordPayment(args: {
  orderId: string;
  provider: "paystack" | "nowpayments";
  providerReference: string;
  amountKobo: number;
  status?: "initialized" | "pending" | "confirmed" | "failed";
  raw?: unknown;
}) {
  const { error } = await supabaseAdmin
    .from("payments")
    .upsert(
      {
        order_id: args.orderId,
        provider: args.provider,
        provider_reference: args.providerReference,
        amount_kobo: args.amountKobo,
        status: args.status ?? "initialized",
        raw_response: (args.raw as any) ?? null,
        verified_at: args.status === "confirmed" ? new Date().toISOString() : null,
      },
      { onConflict: "provider,provider_reference" },
    );
  if (error) throw new Error(error.message);
}

export async function markOrderPaid(orderId: string) {
  const { error } = await supabaseAdmin
    .from("orders")
    .update({ status: "paid" })
    .eq("id", orderId)
    .eq("status", "pending_payment");
  if (error) throw new Error(error.message);
}

export async function findOrderByReference(provider: "paystack" | "nowpayments", reference: string) {
  const { data, error } = await supabaseAdmin
    .from("payments")
    .select("order_id, amount_kobo, status")
    .eq("provider", provider)
    .eq("provider_reference", reference)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data;
}
