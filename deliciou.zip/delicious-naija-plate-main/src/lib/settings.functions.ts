import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";

export type FreeGiftSetting = {
  enabled: boolean;
  threshold_kobo: number;
  item_name: string;
  item_note: string;
};

export type DeliverySetting = {
  base_fee_kobo: number;
  per_km_kobo: number;
  max_radius_km: number;
};

export type HoursSetting = { open_hour: number; close_hour: number; tz: string };

export type PublicSettings = {
  freeGift: FreeGiftSetting;
  delivery: DeliverySetting;
  hours: HoursSetting;
};

const DEFAULTS: PublicSettings = {
  freeGift: { enabled: true, threshold_kobo: 1_500_000, item_name: "Complimentary Small Chops", item_note: "On orders of ₦15,000 and above" },
  delivery: { base_fee_kobo: 100_000, per_km_kobo: 30_000, max_radius_km: 25 },
  hours: { open_hour: 9, close_hour: 19, tz: "Africa/Lagos" },
};

export const getPublicSettings = createServerFn({ method: "GET" }).handler(async (): Promise<PublicSettings> => {
  const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) return DEFAULTS;
  try {
    const supabase = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data, error } = await supabase
      .from("admin_settings")
      .select("key,value")
      .in("key", ["free_gift", "delivery", "hours"]);
    if (error || !data) return DEFAULTS;
    const map = Object.fromEntries(data.map((r: any) => [r.key, r.value]));
    return {
      freeGift: { ...DEFAULTS.freeGift, ...(map.free_gift || {}) },
      delivery: { ...DEFAULTS.delivery, ...(map.delivery || {}) },
      hours: { ...DEFAULTS.hours, ...(map.hours || {}) },
    };
  } catch {
    return DEFAULTS;
  }
});
