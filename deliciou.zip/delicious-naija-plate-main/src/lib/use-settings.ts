import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPublicSettings } from "./settings.functions";

export function usePublicSettings() {
  const fn = useServerFn(getPublicSettings);
  return useQuery({
    queryKey: ["public-settings"],
    queryFn: () => fn(),
    staleTime: 60_000,
  });
}
