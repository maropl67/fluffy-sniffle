import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Loader2, TrendingUp, ShoppingBag, Users, Truck, Package } from "lucide-react";
import { adminAnalytics } from "@/lib/admin.functions";
import { NGN } from "@/lib/format";

export const Route = createFileRoute("/admin/analytics")({
  component: AnalyticsPage,
});

type Range = "daily" | "weekly" | "monthly" | "quarterly" | "yearly" | "custom";

function rangeToDates(r: Range, customFrom?: string, customTo?: string): { from: string; to: string } {
  const to = new Date();
  const from = new Date();
  switch (r) {
    case "daily": from.setHours(0, 0, 0, 0); break;
    case "weekly": from.setDate(to.getDate() - 7); break;
    case "monthly": from.setMonth(to.getMonth() - 1); break;
    case "quarterly": from.setMonth(to.getMonth() - 3); break;
    case "yearly": from.setFullYear(to.getFullYear() - 1); break;
    case "custom":
      return {
        from: customFrom ? new Date(customFrom).toISOString() : from.toISOString(),
        to: customTo ? new Date(customTo).toISOString() : to.toISOString(),
      };
  }
  return { from: from.toISOString(), to: to.toISOString() };
}

function AnalyticsPage() {
  const fn = useServerFn(adminAnalytics);
  const [range, setRange] = useState<Range>("monthly");
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");

  const window = useMemo(() => rangeToDates(range, customFrom, customTo), [range, customFrom, customTo]);
  const { data, isLoading } = useQuery({
    queryKey: ["admin", "analytics", window.from, window.to],
    queryFn: () => fn({ data: window }),
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-3xl text-primary">Revenue tracking</h1>
          <p className="mt-1 text-sm text-muted-foreground">Live metrics across your selected timeframe.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select value={range} onChange={(e) => setRange(e.target.value as Range)}
            className="rounded-lg border border-border bg-background px-3 py-2 text-sm">
            <option value="daily">Today</option>
            <option value="weekly">Last 7 days</option>
            <option value="monthly">Last 30 days</option>
            <option value="quarterly">Last 90 days</option>
            <option value="yearly">Last 12 months</option>
            <option value="custom">Custom</option>
          </select>
          {range === "custom" && (
            <>
              <input type="date" value={customFrom} onChange={(e) => setCustomFrom(e.target.value)}
                className="rounded-lg border border-border bg-background px-3 py-2 text-sm" />
              <input type="date" value={customTo} onChange={(e) => setCustomTo(e.target.value)}
                className="rounded-lg border border-border bg-background px-3 py-2 text-sm" />
            </>
          )}
        </div>
      </div>

      {isLoading || !data ? (
        <Loader2 className="mx-auto mt-12 h-6 w-6 animate-spin text-accent" />
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Stat icon={TrendingUp} label="Total revenue" value={NGN(data.totalRevenue / 100)} />
            <Stat icon={ShoppingBag} label="Average order value" value={NGN(data.aov / 100)} />
            <Stat icon={Package} label="Orders / day" value={data.ordersPerDay.toString()} sub={`${data.count} orders total`} />
            <Stat icon={Truck} label="Delivery vs pickup" value={`${data.deliveryCount} / ${data.pickupCount}`}
              sub={`${data.count ? Math.round((data.deliveryCount / data.count) * 100) : 0}% delivery`} />
            <Stat icon={Users} label="New customers" value={data.newCustomers.toString()} />
            <Stat icon={TrendingUp} label="Customer acquisition cost" value={NGN(data.cac / 100)} sub="Revenue ÷ new customers (proxy)" />
          </div>

          <section className="rounded-3xl border border-border bg-card p-6 shadow-soft">
            <h2 className="font-display text-xl text-primary">Top 5 selling items</h2>
            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <tr><th className="py-2">Item</th><th>Qty</th><th>Revenue</th></tr>
                </thead>
                <tbody>
                  {data.topItems.length === 0 && (
                    <tr><td colSpan={3} className="py-6 text-center text-muted-foreground">No items in this window.</td></tr>
                  )}
                  {data.topItems.map((it: any) => (
                    <tr key={it.name} className="border-t border-border">
                      <td className="py-3 font-medium">{it.name}</td>
                      <td>{it.qty}</td>
                      <td className="font-semibold">{NGN(it.revenue / 100)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="rounded-3xl border border-border bg-card p-6 shadow-soft">
            <h2 className="font-display text-xl text-primary">Daily revenue</h2>
            <div className="mt-4 flex h-40 items-end gap-1">
              {data.series.length === 0 && <p className="text-sm text-muted-foreground">No data.</p>}
              {data.series.map((d: any) => {
                const max = Math.max(...data.series.map((x: any) => x.kobo), 1);
                const h = Math.max(4, (d.kobo / max) * 100);
                return (
                  <div key={d.day} className="flex flex-1 flex-col items-center gap-1" title={`${d.day}: ${NGN(d.kobo / 100)}`}>
                    <div className="w-full rounded-t bg-accent" style={{ height: `${h}%` }} />
                    <span className="text-[9px] text-muted-foreground">{d.day.slice(5)}</span>
                  </div>
                );
              })}
            </div>
          </section>
        </>
      )}
    </div>
  );
}

function Stat({ icon: Icon, label, value, sub }: { icon: any; label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-soft">
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        <Icon className="h-3.5 w-3.5 text-accent" /> {label}
      </div>
      <div className="mt-2 font-display text-2xl text-primary">{value}</div>
      {sub && <div className="mt-0.5 text-xs text-muted-foreground">{sub}</div>}
    </div>
  );
}
