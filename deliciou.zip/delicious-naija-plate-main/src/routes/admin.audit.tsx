import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { adminListAudit } from "@/lib/admin.functions";

export const Route = createFileRoute("/admin/audit")({
  component: AdminAuditPage,
});

function AdminAuditPage() {
  const fetchAudit = useServerFn(adminListAudit);
  const { data, isLoading } = useQuery({ queryKey: ["admin", "audit"], queryFn: () => fetchAudit() });

  if (isLoading) return <Loader2 className="mx-auto mt-12 h-6 w-6 animate-spin text-accent" />;
  const entries = data?.entries ?? [];

  return (
    <div>
      <h1 className="font-display text-3xl text-primary">Audit log</h1>
      <p className="mt-1 text-sm text-muted-foreground">Immutable record of admin & payment events</p>
      <div className="mt-6 overflow-x-auto rounded-2xl border border-border bg-card">
        <table className="w-full min-w-[700px] text-sm">
          <thead className="bg-secondary/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">When</th>
              <th className="px-4 py-3">Action</th>
              <th className="px-4 py-3">Target</th>
              <th className="px-4 py-3">Actor</th>
              <th className="px-4 py-3">Metadata</th>
            </tr>
          </thead>
          <tbody>
            {entries.length === 0 && <tr><td colSpan={5} className="px-4 py-12 text-center text-muted-foreground">No events yet.</td></tr>}
            {entries.map((e: any) => (
              <tr key={e.id} className="border-t border-border align-top">
                <td className="px-4 py-3 text-xs text-muted-foreground">{new Date(e.created_at).toLocaleString()}</td>
                <td className="px-4 py-3 font-mono text-xs">{e.action}</td>
                <td className="px-4 py-3 text-xs">{e.target_type}{e.target_id ? ` · ${e.target_id}` : ""}</td>
                <td className="px-4 py-3 font-mono text-[10px] text-muted-foreground">{e.actor_id?.slice(0, 8) ?? "—"}</td>
                <td className="px-4 py-3"><pre className="max-w-md overflow-x-auto whitespace-pre-wrap break-all text-[10px] text-muted-foreground">{JSON.stringify(e.metadata, null, 2)}</pre></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
