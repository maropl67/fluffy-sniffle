import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Loader2, CheckCircle2, Truck, Package } from "lucide-react";
import { adminListOrders, adminUpdateOrderStatus } from "@/lib/admin.functions";
import { NGN } from "@/lib/format";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/")({
  component: AdminOrdersPage,
});

const STATUSES = ["pending_payment", "paid", "preparing", "out_for_delivery", "ready_for_pickup", "completed", "cancelled", "refunded"] as const;
type Status = typeof STATUSES[number];

function AdminOrdersPage() {
  const fetchOrders = useServerFn(adminListOrders);
  const updateStatus = useServerFn(adminUpdateOrderStatus);
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["admin", "orders"], queryFn: () => fetchOrders() });
  const mut = useMutation({
    mutationFn: (v: { id: string; status: Status }) => updateStatus({ data: v }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin", "orders"] }); toast.success("Order updated"); },
    onError: (e: any) => toast.error(e?.message || "Update failed"),
  });

  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterFulfil, setFilterFulfil] = useState<string>("all");
  const [filterDate, setFilterDate] = useState<string>("");
  const [active, setActive] = useState<any | null>(null);

  const orders = data?.orders ?? [];
  const filtered = useMemo(() => {
    return orders.filter((o: any) => {
      if (filterStatus !== "all" && o.status !== filterStatus) return false;
      if (filterFulfil !== "all" && o.fulfillment !== filterFulfil) return false;
      if (filterDate && new Date(o.created_at).toISOString().slice(0, 10) !== filterDate) return false;
      return true;
    });
  }, [orders, filterStatus, filterFulfil, filterDate]);

  if (isLoading) return <Loader2 className="mx-auto mt-12 h-6 w-6 animate-spin text-accent" />;

  return (
    <div>
      <h1 className="font-display text-3xl text-primary">Orders</h1>
      <p className="mt-1 text-sm text-muted-foreground">{filtered.length} of {orders.length} shown</p>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <select value={filterFulfil} onChange={(e) => setFilterFulfil(e.target.value)}
          className="rounded-lg border border-border bg-background px-3 py-2 text-sm">
          <option value="all">All branches</option>
          <option value="delivery">Delivery</option>
          <option value="pickup">Pickup</option>
        </select>
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}
          className="rounded-lg border border-border bg-background px-3 py-2 text-sm">
          <option value="all">All statuses</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
        </select>
        <input type="date" value={filterDate} onChange={(e) => setFilterDate(e.target.value)}
          className="rounded-lg border border-border bg-background px-3 py-2 text-sm" />
        {filterDate && <button onClick={() => setFilterDate("")} className="text-xs text-accent hover:underline">Clear date</button>}
      </div>

      <div className="mt-6 overflow-x-auto rounded-2xl border border-border bg-card">
        <table className="w-full min-w-[900px] text-sm">
          <thead className="bg-secondary/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Order</th>
              <th className="px-4 py-3">Customer</th>
              <th className="px-4 py-3">Total</th>
              <th className="px-4 py-3">Gift</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Created</th>
              <th className="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={7} className="px-4 py-12 text-center text-muted-foreground">No matching orders.</td></tr>
            )}
            {filtered.map((o: any) => (
              <tr key={o.id} className="border-t border-border align-top hover:bg-secondary/30">
                <td className="px-4 py-3">
                  <button onClick={() => setActive(o)} className="font-mono text-xs text-accent hover:underline">{o.order_number}</button>
                  <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                    {o.fulfillment === "delivery" ? <Truck className="h-3 w-3" /> : <Package className="h-3 w-3" />}
                    {o.fulfillment}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="font-medium">{o.customer_name}</div>
                  <div className="text-xs text-muted-foreground">{o.customer_phone}</div>
                </td>
                <td className="px-4 py-3 font-semibold">{NGN(o.total_kobo / 100)}</td>
                <td className="px-4 py-3">{o.free_gift_applied ? <span className="rounded-full bg-palm/10 px-2 py-0.5 text-xs text-palm">Yes</span> : <span className="text-xs text-muted-foreground">—</span>}</td>
                <td className="px-4 py-3">
                  <select value={o.status}
                    onChange={(e) => mut.mutate({ id: o.id, status: e.target.value as Status })}
                    className="rounded-lg border border-border bg-background px-2 py-1 text-xs">
                    {STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
                  </select>
                </td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString()}</td>
                <td className="px-4 py-3">
                  {o.status !== "completed" && o.status !== "cancelled" && (
                    <button
                      onClick={() => mut.mutate({ id: o.id, status: "completed" })}
                      className="inline-flex items-center gap-1 rounded-full bg-palm/10 px-3 py-1 text-xs font-semibold text-palm hover:bg-palm/20">
                      <CheckCircle2 className="h-3 w-3" /> Mark picked up
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {active && <OrderDetails order={active} onClose={() => setActive(null)} onUpdate={(s) => mut.mutate({ id: active.id, status: s })} />}
    </div>
  );
}

function OrderDetails({ order, onClose, onUpdate }: { order: any; onClose: () => void; onUpdate: (s: Status) => void }) {
  const items = Array.isArray(order.items) ? order.items : [];
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className="max-h-[90vh] w-full max-w-2xl overflow-auto rounded-3xl bg-card p-6 shadow-warm" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between">
          <div>
            <div className="font-mono text-xs text-muted-foreground">{order.order_number}</div>
            <h2 className="mt-1 font-display text-2xl text-primary">{order.customer_name}</h2>
            <div className="text-sm text-muted-foreground">{order.customer_phone} · {order.customer_email}</div>
          </div>
          <button onClick={onClose} className="rounded-full px-3 py-1 text-sm hover:bg-secondary">Close</button>
        </div>

        <div className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
          <Info label="Fulfillment" value={order.fulfillment} />
          <Info label="Status" value={order.status} />
          <Info label="Subtotal" value={NGN(order.subtotal_kobo / 100)} />
          <Info label="Delivery fee" value={NGN(order.delivery_fee_kobo / 100)} />
          <Info label="Total" value={NGN(order.total_kobo / 100)} />
          <Info label="Created" value={new Date(order.created_at).toLocaleString()} />
        </div>

        {order.delivery_address && (
          <div className="mt-3 rounded-lg bg-secondary/50 p-3 text-sm">
            <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Address</div>
            <div>{order.delivery_address}</div>
          </div>
        )}

        <h3 className="mt-5 font-display text-lg text-primary">Items</h3>
        <ul className="mt-2 divide-y divide-border rounded-lg border border-border">
          {items.map((it: any, i: number) => (
            <li key={i} className="flex items-center justify-between px-3 py-2 text-sm">
              <span>{it.name} × {it.qty ?? it.quantity ?? 1}</span>
              <span className="font-semibold">{NGN(((it.price_kobo ?? (it.price ? it.price * 100 : 0)) * (it.qty ?? 1)) / 100)}</span>
            </li>
          ))}
        </ul>

        {order.notes && (
          <div className="mt-3 rounded-lg bg-secondary/50 p-3 text-sm">
            <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Customer notes</div>
            <div>{order.notes}</div>
          </div>
        )}

        <div className="mt-5 flex flex-wrap gap-2">
          {(["preparing", "out_for_delivery", "ready_for_pickup", "completed"] as Status[]).map((s) => (
            <button key={s} onClick={() => { onUpdate(s); onClose(); }}
              className="rounded-full border border-border px-3 py-1.5 text-xs hover:bg-secondary">
              → {s.replace(/_/g, " ")}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="mt-0.5">{value}</div>
    </div>
  );
}
