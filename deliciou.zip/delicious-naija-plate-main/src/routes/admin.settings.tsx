import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Loader2, Save, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { adminGetSettings, adminUpdateSetting } from "@/lib/admin.functions";

export const Route = createFileRoute("/admin/settings")({
  component: AdminSettingsPage,
});

type Branch = { name: string; address: string; email: string; phone: string };

function AdminSettingsPage() {
  const fetchSettings = useServerFn(adminGetSettings);
  const updateSetting = useServerFn(adminUpdateSetting);
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["admin", "settings"], queryFn: () => fetchSettings() });
  const mut = useMutation({
    mutationFn: (v: { key: string; value: any }) => updateSetting({ data: v }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin", "settings"] }); qc.invalidateQueries({ queryKey: ["public-settings"] }); toast.success("Saved"); },
    onError: (e: any) => toast.error(e?.message || "Save failed"),
  });

  const [gift, setGift] = useState({ enabled: true, threshold_kobo: 1500000, item_name: "Complimentary Small Chops", item_note: "On orders of ₦15,000 and above" });
  const [delivery, setDelivery] = useState({ enabled: true, base_fee_kobo: 250000, per_km_kobo: 30000, max_radius_km: 25, fuel_multiplier: 1.0 });
  const [branches, setBranches] = useState<Branch[]>([]);
  const [adminEmail, setAdminEmail] = useState("maroluv755@gmail.com");

  useEffect(() => {
    if (!data) return;
    if (data.settings.free_gift) setGift((g) => ({ ...g, ...data.settings.free_gift }));
    if (data.settings.delivery) setDelivery((d) => ({ ...d, ...data.settings.delivery }));
    if (Array.isArray(data.settings.branches)) setBranches(data.settings.branches);
    if (data.settings.branch_emails?.admin) setAdminEmail(data.settings.branch_emails.admin);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  if (isLoading) return <Loader2 className="mx-auto mt-12 h-6 w-6 animate-spin text-accent" />;

  return (
    <div className="space-y-6 sm:space-y-8">
      <h1 className="font-display text-2xl text-primary sm:text-3xl">Settings</h1>

      <Card title="Delivery" desc="Toggle delivery service on/off and configure how the delivery fee is calculated.">
        <Toggle label="Delivery enabled" desc="Master switch. When off, customers can only choose pickup."
          checked={delivery.enabled} onChange={(v) => setDelivery({ ...delivery, enabled: v })} />
        <Row label="Base fee (₦)" desc="Flat fee added to every delivery order, before distance is calculated.">
          <input type="number" value={Math.round(delivery.base_fee_kobo / 100)} min={0}
            onChange={(e) => setDelivery({ ...delivery, base_fee_kobo: Math.max(0, +e.target.value) * 100 })}
            className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm" />
        </Row>
        <Row label="Per-km fee (₦)" desc="Additional charge per kilometre between the kitchen and the delivery address.">
          <input type="number" value={Math.round(delivery.per_km_kobo / 100)} min={0}
            onChange={(e) => setDelivery({ ...delivery, per_km_kobo: Math.max(0, +e.target.value) * 100 })}
            className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm" />
        </Row>
        <Row label="Max radius (km)" desc="Maximum distance you'll deliver to. Customers further than this can only pick up.">
          <input type="number" value={delivery.max_radius_km} min={0}
            onChange={(e) => setDelivery({ ...delivery, max_radius_km: Math.max(0, +e.target.value) })}
            className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm" />
        </Row>
        <Row label="Fuel price multiplier" desc="Surge factor applied to the per-km fee when fuel prices rise. 1.0 = no surge, 1.5 = +50%.">
          <input type="number" step="0.05" value={delivery.fuel_multiplier} min={0.1}
            onChange={(e) => setDelivery({ ...delivery, fuel_multiplier: Math.max(0.1, +e.target.value) })}
            className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm" />
        </Row>
        <SaveButton onClick={() => mut.mutate({ key: "delivery", value: delivery })} busy={mut.isPending} />
      </Card>

      <Card title="Free gift" desc="Reward customers spending above a threshold with a complimentary item — shown on the home and menu pages.">
        <Toggle label="Free gift enabled" desc="When on, qualifying carts get a free item shown at checkout."
          checked={gift.enabled} onChange={(v) => setGift({ ...gift, enabled: v })} />
        <Row label="Threshold (₦)" desc="Minimum order subtotal that unlocks the free gift.">
          <input type="number" value={Math.round(gift.threshold_kobo / 100)} min={0}
            onChange={(e) => setGift({ ...gift, threshold_kobo: Math.max(0, +e.target.value) * 100 })}
            className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm" />
        </Row>
        <Row label="Gift name" desc="Name shown to customers on the gift banner."><input value={gift.item_name} onChange={(e) => setGift({ ...gift, item_name: e.target.value })} className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm" /></Row>
        <Row label="Gift note" desc="Short helper text shown under the gift name."><input value={gift.item_note} onChange={(e) => setGift({ ...gift, item_note: e.target.value })} className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm" /></Row>
        <SaveButton onClick={() => mut.mutate({ key: "free_gift", value: gift })} busy={mut.isPending} />
      </Card>

      <Card title="Branches" desc="Add, edit or remove restaurant branches. New order notifications are sent to each branch's email.">
        <div className="space-y-4">
          {branches.length === 0 && <p className="text-xs text-muted-foreground">No branches yet — add one below.</p>}
          {branches.map((b, idx) => (
            <div key={idx} className="rounded-2xl border border-border bg-background p-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <LabeledInput label="Name" v={b.name} on={(v) => updateBranch(idx, { ...b, name: v })} placeholder="Lekki branch" />
                <LabeledInput label="Email" v={b.email} on={(v) => updateBranch(idx, { ...b, email: v })} placeholder="lekki@..." />
                <LabeledInput label="Phone" v={b.phone} on={(v) => updateBranch(idx, { ...b, phone: v })} placeholder="0812..." />
                <LabeledInput label="Address" v={b.address} on={(v) => updateBranch(idx, { ...b, address: v })} placeholder="Street, area, city" />
              </div>
              <button onClick={() => setBranches(branches.filter((_, i) => i !== idx))}
                className="mt-3 inline-flex items-center gap-1 text-xs text-destructive hover:underline">
                <Trash2 className="h-3 w-3" /> Remove branch
              </button>
            </div>
          ))}
          <button onClick={() => setBranches([...branches, { name: "", address: "", email: "", phone: "" }])}
            className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 text-xs font-semibold hover:bg-secondary">
            <Plus className="h-3.5 w-3.5" /> Add branch
          </button>
        </div>
        <Row label="Admin email" desc="Always copied on every new order, in addition to branch emails.">
          <input value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)}
            className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm" />
        </Row>
        <div className="flex flex-wrap gap-2">
          <SaveButton onClick={() => mut.mutate({ key: "branches", value: branches })} busy={mut.isPending} label="Save branches" />
          <SaveButton onClick={() => mut.mutate({ key: "branch_emails", value: { admin: adminEmail } })} busy={mut.isPending} label="Save admin email" />
        </div>
      </Card>
    </div>
  );

  function updateBranch(idx: number, next: Branch) {
    setBranches(branches.map((b, i) => (i === idx ? next : b)));
  }
}

function Card({ title, desc, children }: { title: string; desc: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-border bg-card p-4 shadow-soft sm:rounded-3xl sm:p-6">
      <h2 className="font-display text-lg text-primary sm:text-xl">{title}</h2>
      <p className="mt-1 text-xs text-muted-foreground">{desc}</p>
      <div className="mt-4 space-y-3">{children}</div>
    </section>
  );
}
function Row({ label, desc, children }: { label: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="grid gap-1.5 sm:grid-cols-[180px,1fr] sm:items-start sm:gap-4">
      <div className="sm:pt-2">
        <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
        {desc && <div className="mt-0.5 text-[11px] leading-snug text-muted-foreground/80">{desc}</div>}
      </div>
      {children}
    </div>
  );
}
function Toggle({ label, desc, checked, onChange }: { label: string; desc?: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-start gap-3">
      <button type="button" onClick={() => onChange(!checked)}
        className={`relative mt-0.5 h-6 w-11 shrink-0 rounded-full transition ${checked ? "bg-accent" : "bg-muted"}`}>
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition ${checked ? "left-[22px]" : "left-0.5"}`} />
      </button>
      <div>
        <div className="text-sm font-medium">{label}</div>
        {desc && <div className="text-[11px] leading-snug text-muted-foreground">{desc}</div>}
      </div>
    </div>
  );
}
function LabeledInput({ label, v, on, placeholder }: { label: string; v: string; on: (v: string) => void; placeholder?: string }) {
  return (
    <label className="block">
      <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</span>
      <input value={v} onChange={(e) => on(e.target.value)} placeholder={placeholder}
        className="mt-1 block w-full rounded-lg border border-border bg-background px-3 py-2 text-sm" />
    </label>
  );
}
function SaveButton({ onClick, busy, label = "Save" }: { onClick: () => void; busy: boolean; label?: string }) {
  return (
    <button onClick={onClick} disabled={busy}
      className="mt-2 inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-60">
      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} {label}
    </button>
  );
}
