import { createFileRoute, Link, Outlet, redirect, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ShieldCheck, LayoutDashboard, Settings, ScrollText, LogOut, Loader2, BarChart3 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin — Deliciousness Naija" }] }),
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/login" });
    const { data: role } = await supabase.from("user_roles").select("role").eq("user_id", data.user.id).eq("role", "admin").maybeSingle();
    if (!role) throw redirect({ to: "/" });
  },
  component: AdminLayout,
});

const IDLE_TIMEOUT_MS = 15 * 60 * 1000;

function AdminLayout() {
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [idleWarn, setIdleWarn] = useState(false);

  // Idle timeout (admin session)
  useEffect(() => {
    let timer: number | undefined;
    const reset = () => {
      if (timer) window.clearTimeout(timer);
      setIdleWarn(false);
      timer = window.setTimeout(async () => {
        setIdleWarn(true);
        await supabase.auth.signOut();
        navigate({ to: "/login" });
      }, IDLE_TIMEOUT_MS);
    };
    const evts: (keyof WindowEventMap)[] = ["mousemove", "keydown", "click", "touchstart"];
    evts.forEach((e) => window.addEventListener(e, reset));
    reset();
    return () => {
      evts.forEach((e) => window.removeEventListener(e, reset));
      if (timer) window.clearTimeout(timer);
    };
  }, [navigate]);

  // Record every admin page visit (with current user) for the audit trail.
  useEffect(() => {
    (async () => {
      try {
        const { data } = await supabase.auth.getUser();
        await fetch("/api/public/log-admin-visit", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            path: pathname,
            userId: data.user?.id ?? null,
            email: data.user?.email ?? null,
          }),
        });
      } catch {}
    })();
  }, [pathname]);

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/login" });
  }

  const tabs = [
    { to: "/admin", label: "Orders", icon: LayoutDashboard },
    { to: "/admin/analytics", label: "Revenue", icon: BarChart3 },
    { to: "/admin/settings", label: "Settings", icon: Settings },
    { to: "/admin/audit", label: "Audit log", icon: ScrollText },
  ];

  return (
    <div className="min-h-screen bg-secondary/20">
      <div className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-2 text-primary">
            <ShieldCheck className="h-5 w-5 text-accent" />
            <span className="font-display text-lg">Admin Console</span>
          </div>
          <button onClick={signOut} className="flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 text-xs hover:bg-secondary">
            <LogOut className="h-3.5 w-3.5" /> Sign out
          </button>
        </div>
        <nav className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-2 sm:px-4">
          {tabs.map((t) => {
            const active = pathname === t.to;
            return (
              <Link key={t.to} to={t.to}
                className={`flex shrink-0 items-center gap-1.5 border-b-2 px-3 py-2.5 text-sm font-medium transition ${
                  active ? "border-accent text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
                }`}>
                <t.icon className="h-4 w-4" /> {t.label}
              </Link>
            );
          })}
        </nav>
      </div>
      {idleWarn && (
        <div className="bg-accent/10 px-4 py-2 text-center text-xs text-accent">
          <Loader2 className="mr-1 inline h-3 w-3 animate-spin" /> Session expired due to inactivity — signing out…
        </div>
      )}
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <Outlet />
      </main>
    </div>
  );
}
