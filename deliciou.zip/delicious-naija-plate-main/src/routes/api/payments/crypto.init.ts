import { createFileRoute } from "@tanstack/react-router";
import { createPendingOrder, recordPayment } from "@/lib/orders.server";

function isMockKey(key: string | undefined) {
  return !key || key.startsWith("MOCK_") || key === "test_mock";
}

export const Route = createFileRoute("/api/payments/crypto/init")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.NOWPAYMENTS_API_KEY;

        let body: any;
        try { body = await request.json(); } catch { return Response.json({ error: "Invalid body" }, { status: 400 }); }
        const total: number = Number(body?.total);
        if (!Number.isFinite(total) || total <= 0) {
          return Response.json({ error: "Missing amount" }, { status: 400 });
        }

        let order;
        try {
          order = await createPendingOrder({
            customer: body.customer,
            items: body.items,
            subtotal: Number(body.subtotal) || 0,
            deliveryFee: Number(body.deliveryFee) || 0,
            total,
          });
        } catch (e: any) {
          return Response.json({ error: e?.message || "Could not record order" }, { status: 500 });
        }

        const origin = new URL(request.url).origin;
        const order_id = order.order_number;

        // === MOCK MODE — no real NOWPayments key configured ===
        if (isMockKey(key)) {
          await recordPayment({
            orderId: order.id,
            provider: "nowpayments",
            providerReference: order_id,
            amountKobo: Math.round(total * 100),
            status: "initialized",
            raw: { mock: true, note: "MOCK_NOWPAYMENTS_KEY — simulated invoice" },
          });
          return Response.json({
            invoice_url: `${origin}/checkout/success?method=crypto&reference=${encodeURIComponent(order_id)}&mock=1`,
            order_id,
            mock: true,
          });
        }

        const res = await fetch("https://api.nowpayments.io/v1/invoice", {
          method: "POST",
          headers: { "x-api-key": key as string, "Content-Type": "application/json" },
          body: JSON.stringify({
            price_amount: total,
            price_currency: "ngn",
            order_id,
            order_description: `Deliciousness Naija order ${order.order_number}`,
            ipn_callback_url: `${origin}/api/public/crypto-ipn`,
            success_url: `${origin}/checkout/success?method=crypto&reference=${order_id}`,
            cancel_url: `${origin}/checkout`,
          }),
        });
        const data = await res.json();
        if (!res.ok || !data?.invoice_url) {
          return Response.json({ error: data?.message || "Crypto init failed" }, { status: 502 });
        }

        await recordPayment({
          orderId: order.id,
          provider: "nowpayments",
          providerReference: order_id,
          amountKobo: Math.round(total * 100),
          status: "initialized",
        });

        return Response.json({ invoice_url: data.invoice_url, order_id });
      },
    },
  },
});
