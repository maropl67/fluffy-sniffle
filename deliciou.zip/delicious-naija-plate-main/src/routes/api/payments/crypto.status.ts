import { createFileRoute } from "@tanstack/react-router";
import { findOrderByReference, markOrderPaid, recordPayment } from "@/lib/orders.server";

function isMockKey(key: string | undefined) {
  return !key || key.startsWith("MOCK_") || key === "test_mock";
}

export const Route = createFileRoute("/api/payments/crypto/status")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const key = process.env.NOWPAYMENTS_API_KEY;
        const url = new URL(request.url);
        const order_id = url.searchParams.get("order_id");
        const mockFlag = url.searchParams.get("mock") === "1";
        if (!order_id) return Response.json({ status: "failed", message: "Missing order_id" }, { status: 400 });

        // === MOCK MODE ===
        if (isMockKey(key) || mockFlag) {
          const dbPayment = await findOrderByReference("nowpayments", order_id);
          if (!dbPayment) return Response.json({ status: "failed", message: "Order not found" });
          await recordPayment({
            orderId: dbPayment.order_id,
            provider: "nowpayments",
            providerReference: order_id,
            amountKobo: dbPayment.amount_kobo,
            status: "confirmed",
            raw: { mock: true, simulated_at: new Date().toISOString() },
          });
          await markOrderPaid(dbPayment.order_id);
          return Response.json({
            status: "success",
            reference: order_id,
            amount: dbPayment.amount_kobo / 100,
            mock: true,
          });
        }

        const res = await fetch(`https://api.nowpayments.io/v1/payment/?orderId=${encodeURIComponent(order_id)}&limit=1`, {
          headers: { "x-api-key": key as string },
        });
        const data = await res.json();
        if (!res.ok) return Response.json({ status: "failed", message: data?.message || "Lookup failed" });
        const payment = data?.data?.[0];
        if (!payment) return Response.json({ status: "pending" });

        const s = payment.payment_status;
        const dbPayment = await findOrderByReference("nowpayments", order_id);

        if (s === "finished" || s === "confirmed") {
          if (dbPayment) {
            await recordPayment({
              orderId: dbPayment.order_id,
              provider: "nowpayments",
              providerReference: order_id,
              amountKobo: dbPayment.amount_kobo,
              status: "confirmed",
              raw: payment,
            });
            await markOrderPaid(dbPayment.order_id);
          }
          return Response.json({ status: "success", reference: order_id, amount: payment.price_amount });
        }
        if (["failed", "expired", "refunded"].includes(s)) {
          return Response.json({ status: "failed", message: `Crypto payment ${s}` });
        }
        return Response.json({ status: "pending" });
      },
    },
  },
});
