import { createFileRoute } from "@tanstack/react-router";
import { createPendingOrder, recordPayment } from "@/lib/orders.server";

function getOrigin(req: Request) {
  return new URL(req.url).origin;
}

function isMockKey(key: string | undefined) {
  return !key || key.startsWith("MOCK_") || key === "sk_test_mock";
}

export const Route = createFileRoute("/api/payments/paystack/init")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.PAYSTACK_SECRET_KEY;
        let body: any;
        try { body = await request.json(); } catch { return Response.json({ error: "Invalid body" }, { status: 400 }); }
        const total: number = Number(body?.total);
        const email: string = String(body?.customer?.email || "").trim();
        if (!email || !Number.isFinite(total) || total <= 0) {
          return Response.json({ error: "Missing email or amount" }, { status: 400 });
        }

        // 1. Create DB order in pending state
        let order;
        try {
          order = await createPendingOrder({
            customer: body.customer,
            items: body.items,
            subtotal: Number(body.subtotal) || 0,
            deliveryFee: Number(body.deliveryFee) || 0,
            total,
          });
        } catch (e: any) {
          return Response.json({ error: e?.message || "Could not record order" }, { status: 500 });
        }

        const reference = order.order_number;
        const origin = getOrigin(request);

        // === MOCK MODE — no real Paystack key configured ===
        if (isMockKey(key)) {
          await recordPayment({
            orderId: order.id,
            provider: "paystack",
            providerReference: reference,
            amountKobo: Math.round(total * 100),
            status: "initialized",
            raw: { mock: true, note: "MOCK_PAYSTACK_KEY — simulated payment" },
          });
          return Response.json({
            authorization_url: `${origin}/checkout/success?method=card&reference=${encodeURIComponent(reference)}&mock=1`,
            reference,
            order_id: order.id,
            mock: true,
          });
        }

        const callback_url = `${origin}/checkout/success?method=card`;
        const itemSummary = (body.items || []).slice(0, 20).map((l: any) => `${l.qty}x ${l.name}${l.size ? ` (${l.size})` : ""}`).join(", ");

        const res = await fetch("https://api.paystack.co/transaction/initialize", {
          method: "POST",
          headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            email,
            amount: Math.round(total * 100),
            currency: "NGN",
            reference,
            callback_url,
            metadata: { order_id: order.id, items_summary: itemSummary },
          }),
        });
        const data = await res.json();
        if (!res.ok || !data?.status) {
          return Response.json({ error: data?.message || "Paystack init failed" }, { status: 502 });
        }

        await recordPayment({
          orderId: order.id,
          provider: "paystack",
          providerReference: data.data.reference,
          amountKobo: Math.round(total * 100),
          status: "initialized",
        });

        return Response.json({
          authorization_url: data.data.authorization_url,
          reference: data.data.reference,
          order_id: order.id,
        });
      },
    },
  },
});
