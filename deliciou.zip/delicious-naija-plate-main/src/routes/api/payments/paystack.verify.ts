import { createFileRoute } from "@tanstack/react-router";
import { findOrderByReference, markOrderPaid, recordPayment } from "@/lib/orders.server";

function isMockKey(key: string | undefined) {
  return !key || key.startsWith("MOCK_") || key === "sk_test_mock";
}

export const Route = createFileRoute("/api/payments/paystack/verify")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const key = process.env.PAYSTACK_SECRET_KEY;
        const url = new URL(request.url);
        const reference = url.searchParams.get("reference");
        const mockFlag = url.searchParams.get("mock") === "1";
        if (!reference) return Response.json({ status: "failed", message: "Missing reference" }, { status: 400 });

        // === MOCK MODE ===
        if (isMockKey(key) || mockFlag) {
          const payment = await findOrderByReference("paystack", reference);
          if (!payment) {
            return Response.json({ status: "failed", message: "Order not found" });
          }
          await recordPayment({
            orderId: payment.order_id,
            provider: "paystack",
            providerReference: reference,
            amountKobo: payment.amount_kobo,
            status: "confirmed",
            raw: { mock: true, simulated_at: new Date().toISOString() },
          });
          await markOrderPaid(payment.order_id);
          return Response.json({
            status: "success",
            reference,
            amount: payment.amount_kobo / 100,
            mock: true,
          });
        }

        const res = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
          headers: { Authorization: `Bearer ${key}` },
        });
        const data = await res.json();
        if (!res.ok || !data?.status) {
          return Response.json({ status: "failed", message: data?.message || "Verification failed" });
        }
        const tx = data.data;
        const payment = await findOrderByReference("paystack", reference);

        if (tx.status === "success") {
          if (payment) {
            if (tx.amount !== payment.amount_kobo) {
              return Response.json({ status: "failed", message: "Amount mismatch" });
            }
            await recordPayment({
              orderId: payment.order_id,
              provider: "paystack",
              providerReference: reference,
              amountKobo: tx.amount,
              status: "confirmed",
              raw: tx,
            });
            await markOrderPaid(payment.order_id);
          }
          return Response.json({ status: "success", reference, amount: tx.amount / 100, paid_at: tx.paid_at });
        }
        if (tx.status === "pending" || tx.status === "ongoing") {
          return Response.json({ status: "pending" });
        }
        return Response.json({ status: "failed", message: tx.gateway_response || "Payment not successful" });
      },
    },
  },
});
