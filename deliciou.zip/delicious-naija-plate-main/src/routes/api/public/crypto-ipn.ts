// NOWPayments IPN — verifies HMAC and finalizes crypto order.
import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";
import { findOrderByReference, markOrderPaid, recordPayment } from "@/lib/orders.server";

function sortedStringify(obj: any): string {
  if (obj === null || typeof obj !== "object") return JSON.stringify(obj);
  if (Array.isArray(obj)) return "[" + obj.map(sortedStringify).join(",") + "]";
  const keys = Object.keys(obj).sort();
  return "{" + keys.map((k) => JSON.stringify(k) + ":" + sortedStringify(obj[k])).join(",") + "}";
}

export const Route = createFileRoute("/api/public/crypto-ipn")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env.NOWPAYMENTS_IPN_SECRET;
        if (!secret) return new Response("Not configured", { status: 500 });
        const sig = request.headers.get("x-nowpayments-sig") ?? "";
        const body = await request.text();
        const expected = createHmac("sha512", secret).update(sortedStringify(JSON.parse(body))).digest("hex");
        const sigBuf = Buffer.from(sig);
        const expBuf = Buffer.from(expected);
        if (sigBuf.length !== expBuf.length || !timingSafeEqual(sigBuf, expBuf)) {
          return new Response("Invalid signature", { status: 401 });
        }
        const event = JSON.parse(body);
        const order_id = event.order_id as string;
        const status = event.payment_status as string;

        if (status === "finished" || status === "confirmed") {
          const dbPayment = await findOrderByReference("nowpayments", order_id);
          if (dbPayment) {
            await recordPayment({
              orderId: dbPayment.order_id, provider: "nowpayments",
              providerReference: order_id, amountKobo: dbPayment.amount_kobo,
              status: "confirmed", raw: event,
            });
            await markOrderPaid(dbPayment.order_id);
          }
        }
        return new Response("ok");
      },
    },
  },
});
