import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const Route = createFileRoute("/api/public/log-admin-visit")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const body = await request.json().catch(() => ({} as any));
          const path = typeof body.path === "string" ? body.path.slice(0, 255) : null;
          const userId = typeof body.userId === "string" ? body.userId : null;
          const email = typeof body.email === "string" ? body.email.slice(0, 255) : null;
          const ip = request.headers.get("cf-connecting-ip") || request.headers.get("x-forwarded-for") || null;
          const ua = request.headers.get("user-agent") || null;
          await supabaseAdmin.from("audit_logs").insert({
            actor_id: userId,
            action: userId ? "admin.page.view" : "admin.page.visit_anonymous",
            target_type: "route", target_id: path,
            metadata: { email, ip, user_agent: ua },
            ip, user_agent: ua,
          });
          return Response.json({ ok: true });
        } catch (e: any) {
          return Response.json({ ok: false, error: e?.message }, { status: 200 });
        }
      },
    },
  },
});
