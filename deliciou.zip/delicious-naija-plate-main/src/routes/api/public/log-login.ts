import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const Route = createFileRoute("/api/public/log-login")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const body = await request.json().catch(() => ({} as any));
          const email = typeof body.email === "string" ? body.email.slice(0, 255) : null;
          const success = !!body.success;
          const reason = typeof body.reason === "string" ? body.reason.slice(0, 255) : null;
          const ip = request.headers.get("cf-connecting-ip") || request.headers.get("x-forwarded-for") || null;
          const ua = request.headers.get("user-agent") || null;
          await supabaseAdmin.from("login_attempts").insert({
            email, success, ip, user_agent: ua,
          });
          // Also write a non-actor audit entry for visibility
          await supabaseAdmin.from("audit_logs").insert({
            actor_id: null,
            action: success ? "auth.login.success" : "auth.login.failed",
            target_type: "auth", target_id: email,
            metadata: { reason, ip, user_agent: ua },
            ip, user_agent: ua,
          });
          return Response.json({ ok: true });
        } catch (e: any) {
          return Response.json({ ok: false, error: e?.message }, { status: 200 });
        }
      },
    },
  },
});
