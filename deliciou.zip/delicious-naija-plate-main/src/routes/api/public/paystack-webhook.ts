// Paystack webhook — verifies HMAC and finalizes order if successful.
import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";
import { findOrderByReference, markOrderPaid, recordPayment } from "@/lib/orders.server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const Route = createFileRoute("/api/public/paystack-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.PAYSTACK_SECRET_KEY;
        if (!key) return new Response("Not configured", { status: 500 });

        const sig = request.headers.get("x-paystack-signature") ?? "";
        const body = await request.text();
        const expected = createHmac("sha512", key).update(body).digest("hex");
        const sigBuf = Buffer.from(sig);
        const expBuf = Buffer.from(expected);
        if (sigBuf.length !== expBuf.length || !timingSafeEqual(sigBuf, expBuf)) {
          return new Response("Invalid signature", { status: 401 });
        }

        const event = JSON.parse(body);
        try {
          await supabaseAdmin.from("audit_logs").insert({
            action: "paystack.webhook",
            target_type: "payment",
            target_id: event?.data?.reference ?? null,
            metadata: { event: event?.event },
          });
        } catch {}

        if (event?.event === "charge.success") {
          const ref = event.data.reference as string;
          const amount = event.data.amount as number;
          const dbPayment = await findOrderByReference("paystack", ref);
          if (dbPayment && amount === dbPayment.amount_kobo) {
            await recordPayment({
              orderId: dbPayment.order_id, provider: "paystack",
              providerReference: ref, amountKobo: amount,
              status: "confirmed", raw: event.data,
            });
            await markOrderPaid(dbPayment.order_id);
          }
        }
        return new Response("ok");
      },
    },
  },
});
