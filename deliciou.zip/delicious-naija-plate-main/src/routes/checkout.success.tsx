import { createFileRoute, Link, useSearch } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CheckCircle2, Loader2, XCircle, Clock } from "lucide-react";
import { NGN } from "@/lib/format";

type Status = "checking" | "success" | "pending" | "failed";

export const Route = createFileRoute("/checkout/success")({
  head: () => ({ meta: [{ title: "Order Status — Deliciousness Naija Catering" }] }),
  validateSearch: (s: Record<string, unknown>) => ({
    reference: (s.reference as string) || (s.trxref as string) || "",
    method: ((s.method as string) || "card") as "card" | "crypto",
  }),
  component: SuccessPage,
});

function SuccessPage() {
  const { reference, method } = useSearch({ from: "/checkout/success" });
  const [status, setStatus] = useState<Status>("checking");
  const [order, setOrder] = useState<any>(null);
  const [message, setMessage] = useState("");

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem("dn-pending-order");
      if (raw) setOrder(JSON.parse(raw));
    } catch {}
  }, []);

  useEffect(() => {
    if (!reference) { setStatus("failed"); setMessage("Missing payment reference"); return; }
    let cancelled = false;
    let attempts = 0;

    async function poll() {
      attempts++;
      const url = method === "crypto"
        ? `/api/payments/crypto/status?order_id=${encodeURIComponent(reference)}`
        : `/api/payments/paystack/verify?reference=${encodeURIComponent(reference)}`;
      try {
        const res = await fetch(url);
        const data = await res.json();
        if (cancelled) return;
        if (data.status === "success") {
          setStatus("success");
          sessionStorage.removeItem("dn-pending-order");
        } else if (data.status === "pending") {
          setStatus("pending");
          if (attempts < 30) setTimeout(poll, 5000);
        } else {
          setStatus("failed");
          setMessage(data.message || "Payment was not successful");
        }
      } catch (e: any) {
        if (!cancelled) {
          setStatus("failed");
          setMessage(e?.message || "Could not verify payment");
        }
      }
    }
    poll();
    return () => { cancelled = true; };
  }, [reference, method]);

  return (
    <div className="mx-auto max-w-2xl px-6 py-20">
      <div className="rounded-3xl border border-border bg-card p-10 text-center shadow-soft">
        {status === "checking" && (
          <>
            <Loader2 className="mx-auto h-14 w-14 animate-spin text-accent" />
            <h1 className="mt-5 font-display text-3xl text-primary">Verifying payment…</h1>
            <p className="mt-2 text-sm text-muted-foreground">Hold tight — we're confirming your payment with the gateway.</p>
          </>
        )}
        {status === "pending" && (
          <>
            <Clock className="mx-auto h-14 w-14 text-gold" />
            <h1 className="mt-5 font-display text-3xl text-primary">Payment pending</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {method === "crypto"
                ? "Waiting for blockchain confirmations — this can take a few minutes."
                : "We're still confirming your payment. This page will update automatically."}
            </p>
          </>
        )}
        {status === "success" && (
          <>
            <CheckCircle2 className="mx-auto h-16 w-16 text-palm" />
            <h1 className="mt-5 font-display text-4xl text-primary">Payment confirmed!</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Your order is now with our kitchen. We'll contact you on the phone you provided.
            </p>
            {order && (
              <div className="mt-7 rounded-2xl bg-secondary/50 p-5 text-left">
                <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Order reference</div>
                <div className="mt-1 break-all font-mono text-sm">{reference}</div>
                <div className="mt-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Total paid</div>
                <div className="mt-1 font-display text-2xl text-primary">{NGN(order.total)}</div>
              </div>
            )}
            <div className="mt-7 flex justify-center gap-3">
              <Link to="/" className="rounded-full border border-border px-5 py-2.5 text-sm font-semibold hover:bg-secondary">Home</Link>
              <Link to="/menu" className="rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90">Order more</Link>
            </div>
          </>
        )}
        {status === "failed" && (
          <>
            <XCircle className="mx-auto h-14 w-14 text-destructive" />
            <h1 className="mt-5 font-display text-3xl text-primary">Payment not confirmed</h1>
            <p className="mt-2 text-sm text-muted-foreground">{message || "Please try again."}</p>
            <Link to="/checkout" className="mt-6 inline-flex rounded-full bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90">
              Back to checkout
            </Link>
          </>
        )}
      </div>
    </div>
  );
}
