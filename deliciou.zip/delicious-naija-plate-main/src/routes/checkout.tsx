import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { CreditCard, Bitcoin, Loader2, Lock, MapPin, Gift } from "lucide-react";
import { useCart } from "@/lib/cart";
import { NGN } from "@/lib/format";
import { useNigeriaHours, RESTAURANT_ADDRESS } from "@/lib/hours";
import { usePublicSettings } from "@/lib/use-settings";
import { evaluateGift } from "@/lib/free-gift";

export const Route = createFileRoute("/checkout")({
  head: () => ({ meta: [{ title: "Checkout — Deliciousness Naija Catering" }] }),
  component: CheckoutPage,
});

const DELIVERY_FEE = 2500;
const NG_PHONE = /^(?:\+234\d{10}|0\d{10})$/;

const schema = z.object({
  name: z.string().trim().min(2, "Enter your name").max(80),
  phone: z.string().trim().regex(NG_PHONE, "Use a Nigerian number — 07XXXXXXXXX or +234XXXXXXXXX"),
  email: z.string().trim().email("Enter a valid email").max(120).optional().or(z.literal("")),
  fulfilment: z.enum(["delivery", "pickup"]),
  address: z.string().trim().max(300).optional(),
  time: z.string().trim().max(60).optional(),
  notes: z.string().trim().max(400).optional(),
  payment: z.enum(["card", "crypto"]),
});

function CheckoutPage() {
  const navigate = useNavigate();
  const { lines, subtotal, clear } = useCart();
  const { deliveryOpen, status } = useNigeriaHours();
  const { data: settings } = usePublicSettings();
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    name: "", phone: "", email: "",
    fulfilment: (deliveryOpen ? "delivery" : "pickup") as "delivery" | "pickup",
    address: "", time: "", notes: "",
    payment: "card" as "card" | "crypto",
  });

  const sub = subtotal();
  const fee = form.fulfilment === "delivery" ? DELIVERY_FEE : 0;
  const total = sub + fee;
  const gift = evaluateGift(sub, settings?.freeGift);

  if (lines.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-6 py-32 text-center">
        <h1 className="font-display text-3xl text-primary">Your cart is empty</h1>
        <p className="mt-2 text-muted-foreground">Add some delicious items to checkout.</p>
        <Link to="/menu" className="mt-6 inline-flex rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90">
          Browse menu
        </Link>
      </div>
    );
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    if (parsed.data.fulfilment === "delivery" && !parsed.data.address?.trim()) {
      toast.error("Enter your delivery address");
      return;
    }
    if (parsed.data.fulfilment === "delivery" && !deliveryOpen) {
      toast.error("Delivery is currently closed. Please choose Pickup.");
      return;
    }
    if (parsed.data.payment === "card" && !parsed.data.email?.trim()) {
      toast.error("Card payments require an email — Paystack sends the receipt there.");
      return;
    }
    setSubmitting(true);
    try {
      const orderPayload = {
        customer: parsed.data,
        items: lines,
        subtotal: sub,
        deliveryFee: fee,
        total,
      };

      if (parsed.data.payment === "card") {
        const res = await fetch("/api/payments/paystack/init", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(orderPayload),
        });
        const data = await res.json();
        if (!res.ok || !data.authorization_url) {
          throw new Error(data.error || "Could not start payment");
        }
        sessionStorage.setItem("dn-pending-order", JSON.stringify({ ...orderPayload, reference: data.reference }));
        window.location.href = data.authorization_url;
      } else {
        const res = await fetch("/api/payments/crypto/init", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(orderPayload),
        });
        const data = await res.json();
        if (!res.ok || !data.invoice_url) {
          throw new Error(data.error || "Could not start crypto payment");
        }
        sessionStorage.setItem("dn-pending-order", JSON.stringify({ ...orderPayload, reference: data.order_id }));
        window.location.href = data.invoice_url;
      }
      clear();
    } catch (err: any) {
      toast.error(err?.message || "Payment could not start");
      setSubmitting(false);
    }
  }

  return (
    <div className="bg-secondary/20">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <h1 className="font-display text-4xl text-primary sm:text-5xl">Checkout</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Almost there — your order ships only after payment is confirmed.{" "}
          <span className="font-medium text-foreground">Fields marked <span className="text-accent">*</span> are required.</span>
        </p>

        <form onSubmit={onSubmit} className="mt-10 grid gap-8 lg:grid-cols-[1fr,420px]">
          <div className="space-y-8">
            <Section title="Your details">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field required label="Name" v={form.name} on={(v) => setForm({ ...form, name: v })}
                  hint="Use your bank account name for easier identification." />
                <Field required label="Phone" v={form.phone} on={(v) => setForm({ ...form, phone: v })}
                  placeholder="07XXXXXXXXX or +234XXXXXXXXX"
                  hint="Nigerian numbers only." />
                <Field label="Email (optional)" type="email" v={form.email} on={(v) => setForm({ ...form, email: v })} className="sm:col-span-2" hint="We'll send the order receipt here if provided." />
              </div>
            </Section>

            <Section title="Fulfilment">
              {!deliveryOpen && (
                <p className="mb-3 rounded-lg bg-secondary/60 px-3 py-2 text-xs text-muted-foreground">
                  {status}. Pickup is still available.
                </p>
              )}
              <div className="grid gap-3 sm:grid-cols-2">
                {(["delivery", "pickup"] as const).map(opt => {
                  const disabled = opt === "delivery" && !deliveryOpen;
                  return (
                    <button
                      type="button"
                      key={opt}
                      disabled={disabled}
                      onClick={() => setForm({ ...form, fulfilment: opt })}
                      className={`rounded-2xl border-2 p-4 text-left transition ${
                        form.fulfilment === opt
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-accent"
                      } ${disabled ? "cursor-not-allowed opacity-50" : ""}`}
                    >
                      <div className="font-semibold capitalize">{opt} <span className="text-accent">*</span></div>
                      <div className="text-xs text-muted-foreground">
                        {opt === "delivery" ? `Across Lagos · ${NGN(DELIVERY_FEE)}` : "Pick up at Oshodi HQ · Free"}
                      </div>
                    </button>
                  );
                })}
              </div>

              {form.fulfilment === "delivery" && (
                <>
                  <Field required className="mt-4" label="Delivery address" v={form.address}
                    on={(v) => setForm({ ...form, address: v })}
                    placeholder="House no, street, area, Lagos" />
                  <Field className="mt-4" label="Preferred delivery time (optional)"
                    type="datetime-local" v={form.time} on={(v) => setForm({ ...form, time: v })}
                    hint="Within delivery hours (9am – 7pm)." />
                </>
              )}

              {form.fulfilment === "pickup" && (
                <div className="mt-4 flex gap-3 rounded-2xl border border-border bg-secondary/40 p-4">
                  <MapPin className="h-5 w-5 shrink-0 text-accent" />
                  <div className="text-sm">
                    <div className="font-semibold">Pickup address</div>
                    <p className="text-muted-foreground">{RESTAURANT_ADDRESS}</p>
                  </div>
                </div>
              )}

              <Field className="mt-4" label="Notes (optional)" v={form.notes}
                on={(v) => setForm({ ...form, notes: v })}
                placeholder="Allergies, extra spicy, etc." />
            </Section>

            <Section title="Payment method">
              <div className="grid gap-3 sm:grid-cols-2">
                <PaymentChoice
                  active={form.payment === "card"}
                  onClick={() => setForm({ ...form, payment: "card" })}
                  icon={<CreditCard className="h-5 w-5" />}
                  title="Card / Bank Transfer"
                  desc="Pay securely with any Naira card, USSD or bank transfer via Paystack."
                />
                <PaymentChoice
                  active={form.payment === "crypto"}
                  onClick={() => setForm({ ...form, payment: "crypto" })}
                  icon={<Bitcoin className="h-5 w-5" />}
                  title="Crypto"
                  desc="Pay with BTC, USDT, ETH and more. Order ships after on-chain confirmation."
                />
              </div>
              <p className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
                <Lock className="h-3.5 w-3.5" /> Your order is only submitted to the kitchen after payment is confirmed.
              </p>
            </Section>
          </div>

          <aside className="sticky top-24 h-fit rounded-3xl border border-border bg-card p-6 shadow-soft">
            <h2 className="font-display text-xl text-primary">Order summary</h2>
            <ul className="mt-4 max-h-64 space-y-3 overflow-y-auto pr-1 text-sm">
              {lines.map(l => (
                <li key={l.id} className="flex justify-between gap-3">
                  <span className="min-w-0">
                    <span className="font-semibold">{l.qty}× {l.name}</span>
                    {l.size && <span className="ml-1 text-xs text-muted-foreground">({l.size})</span>}
                  </span>
                  <span>{NGN(l.unitPrice * l.qty)}</span>
                </li>
              ))}
            </ul>
            <div className="mt-5 space-y-1.5 border-t border-border pt-4 text-sm">
              <Row k="Subtotal" v={NGN(sub)} />
              <Row k="Delivery" v={fee ? NGN(fee) : "Free"} />
              <Row k="Total" v={NGN(total)} big />
            </div>
            {gift && (
              <div className={`mt-4 rounded-2xl border p-3 text-xs ${gift.eligible ? "border-palm/40 bg-palm/10 text-palm" : "border-border bg-secondary/40 text-muted-foreground"}`}>
                <div className="flex items-center gap-2 font-semibold">
                  <Gift className="h-4 w-4" />
                  {gift.eligible
                    ? `Free ${gift.itemName} included with this order!`
                    : `Add ${NGN(gift.remainingKobo / 100)} more to unlock a free ${gift.itemName}`}
                </div>
                <div className="mt-0.5">{gift.note}</div>
              </div>
            )}
            <button
              type="submit"
              disabled={submitting}
              className="mt-6 grid w-full place-items-center rounded-full bg-accent py-3.5 text-sm font-bold text-accent-foreground shadow-warm transition hover:bg-accent/90 disabled:opacity-60"
            >
              {submitting
                ? <span className="inline-flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Starting payment…</span>
                : `Pay ${NGN(total)}`}
            </button>
            <button type="button" onClick={() => navigate({ to: "/menu" })} className="mt-2 w-full text-xs text-muted-foreground hover:text-accent">
              ← Add more items
            </button>
          </aside>
        </form>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-3xl border border-border bg-card p-6 shadow-soft">
      <h2 className="font-display text-xl text-primary">{title}</h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}

function Field({ label, v, on, type = "text", placeholder, className, required, hint }: {
  label: string; v: string; on: (v: string) => void; type?: string; placeholder?: string;
  className?: string; required?: boolean; hint?: string;
}) {
  return (
    <label className={`block ${className ?? ""}`}>
      <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {label} {required && <span className="text-accent">*</span>}
      </span>
      <input
        type={type}
        value={v}
        onChange={(e) => on(e.target.value)}
        placeholder={placeholder}
        required={required}
        className="mt-1.5 block w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/30"
      />
      {hint && <span className="mt-1 block text-[11px] text-muted-foreground">{hint}</span>}
    </label>
  );
}

function PaymentChoice({ active, onClick, icon, title, desc }: {
  active: boolean; onClick: () => void; icon: React.ReactNode; title: string; desc: string;
}) {
  return (
    <button type="button" onClick={onClick}
      className={`flex gap-3 rounded-2xl border-2 p-4 text-left transition ${
        active ? "border-accent bg-accent/5" : "border-border hover:border-accent/50"
      }`}>
      <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-full ${active ? "bg-accent text-accent-foreground" : "bg-secondary text-secondary-foreground"}`}>
        {icon}
      </div>
      <div>
        <div className="font-semibold">{title}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
    </button>
  );
}

function Row({ k, v, big }: { k: string; v: string; big?: boolean }) {
  return (
    <div className={`flex items-baseline justify-between ${big ? "pt-3 text-base font-bold text-primary" : "text-muted-foreground"}`}>
      <span>{k}</span>
      <span className={big ? "font-display text-2xl" : ""}>{v}</span>
    </div>
  );
}
