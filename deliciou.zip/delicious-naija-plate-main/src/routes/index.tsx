import { createFileRoute, Link } from "@tanstack/react-router";
import { Star, MapPin, Phone, Clock, Flame, Truck, Sparkles, ChefHat, ShoppingBag, BookOpen } from "lucide-react";
import { useNigeriaHours } from "@/lib/hours";
import heroJollof from "@/assets/hero-jollof.jpg";
import { CATEGORIES } from "@/data/menu";
import { GiftBanner } from "@/components/site/GiftBanner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Deliciousness Naija Catering — Lagos' Best Smokey Jollof" },
      { name: "description", content: "Freshly made Nigerian delicacies in Lekki, Lagos. Smokey jollof, native soups, platters and small chops — delivered fast. Pay with card or crypto." },
    ],
  }),
  component: Home,
});

// Profile picture: DiceBear "initials" avatars — deterministic, no PII, no network photos of real reviewers.
const avatarFor = (name: string, bg: string) =>
  `https://api.dicebear.com/9.x/initials/svg?seed=${encodeURIComponent(name)}&backgroundColor=${bg}&fontFamily=Georgia&fontWeight=600&radius=50`;

const REVIEWS = [
  { name: "Motunrayo Mary Babawande", stars: 5, when: "3 years ago",
    avatar: avatarFor("Motunrayo Babawande", "c8553d"),
    text: "If you need a place to get homemade delicacies, try their smokey jollof rice and egusi soup. It's the best… I highly recommend them." },
  { name: "Glory Ibhafidon", stars: 5, when: "5 months ago",
    avatar: avatarFor("Glory Ibhafidon", "2f6a4f"),
    text: "I had an amazing experience with this food vendor! The food was delicious, freshly prepared, and full of rich flavor. You can tell they put a lot of care and passion into every dish. Delivery was on point too 😘" },
  { name: "Anne Maloney", stars: 5, when: "2 weeks ago",
    avatar: avatarFor("Anne Maloney", "b8860b"),
    text: "A friend recommended this brand to me and I've got no regret. Their Eforiro tasted more like my grandma's. Will there be a next time? YES 😋🤤" },
  { name: "Blessing Imoh", stars: 5, when: "2 weeks ago",
    avatar: avatarFor("Blessing Imoh", "8b3a3a"),
    text: "I ordered the Seafood Basmati Fried Rice and it was absolutely worth it! Rich, flavorful, and perfectly cooked with generous seafood portions. Definitely one of the best seafood rice dishes I've had." },
  { name: "Blessing Ukeh", stars: 4, when: "2 years ago",
    avatar: avatarFor("Blessing Ukeh", "4a5d3a"),
    text: "Really nice ever, best taste ever imagine — especially the CEO. God bless." },
];

function Home() {
  const { deliveryOpen, status } = useNigeriaHours();
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden bg-charcoal text-cream">
        <img
          src={heroJollof}
          alt="Steaming smokey jollof rice"
          width={1920}
          height={1080}
          className="absolute inset-0 h-full w-full object-cover opacity-55"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-charcoal via-charcoal/85 to-charcoal/30" />
        <div className="relative mx-auto max-w-7xl px-6 py-14 sm:py-20 lg:py-24">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-gold">
              <Flame className="h-3.5 w-3.5" /> Freshly Made • Since day one
            </div>
            <h1 className="mt-4 font-display text-4xl font-bold leading-[1.05] text-cream sm:text-5xl lg:text-6xl text-balance">
              Smokey Jollof,<br />
              <span className="text-gold">native flavours.</span>
            </h1>
            <p className="mt-4 max-w-xl text-sm text-cream/80 sm:text-base text-balance">
              Lagos' most-loved kitchen — <b className="text-cream">775,000+</b> followers and the boldest Nigerian flavours, delivered hot to your door.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link to="/menu"
                className="inline-flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-bold text-accent-foreground shadow-warm transition hover:scale-[1.02] hover:bg-accent/90">
                <BookOpen className="h-4 w-4" /> Explore menu
              </Link>
              <a href="tel:+2348120633599"
                className="inline-flex items-center gap-2 rounded-full border border-cream/30 px-6 py-3 text-sm font-semibold text-cream transition hover:bg-cream/10">
                <Phone className="h-4 w-4" /> 0812 063 3599
              </a>
            </div>
            <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-cream/70 sm:text-sm">
              <div className="flex items-center gap-2"><Star className="h-4 w-4 fill-gold text-gold" /> 3.9 · 32 reviews</div>
              <div>🥘 100% freshly made</div>
              <div className="flex items-center gap-1.5">
                <span className={`h-2 w-2 rounded-full ${deliveryOpen ? "bg-emerald-400" : "bg-rose-400"}`} />
                {status}
              </div>
            </div>
          </div>
        </div>
      </section>


      {/* VALUE STRIP */}
      <section className="border-y border-border bg-secondary/40">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px bg-border md:grid-cols-4">
          {[
            { icon: ChefHat, t: "Freshly Made", d: "Cooked to order daily" },
            { icon: Truck,   t: "Fast Delivery", d: "Via Chowdeck & Glovo" },
            { icon: Sparkles,t: "Loved by Lagos", d: "775K+ social followers" },
            { icon: Flame,   t: "Signature Smoke", d: "Real wood-fire jollof" },
          ].map(({ icon: Icon, t, d }) => (
            <div key={t} className="flex items-center gap-3 bg-background px-5 py-5">
              <Icon className="h-8 w-8 text-accent" />
              <div>
                <div className="text-sm font-semibold">{t}</div>
                <div className="text-xs text-muted-foreground">{d}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ABOUT */}
      <section id="about" className="mx-auto max-w-7xl px-6 py-20 lg:py-28">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <div className="text-xs uppercase tracking-[0.25em] text-accent">Our story</div>
            <h2 className="mt-3 font-display text-4xl text-primary sm:text-5xl text-balance">
              From our pot, with passion — to your plate.
            </h2>
            <p className="mt-5 text-base text-muted-foreground">
              Deliciousness Naija Catering started with one mission: serve the bold, soulful taste of home —
              the kind your grandma made on Sunday afternoons — without compromise. Today we cater
              everything from intimate weekend dinners to thousand-plate weddings across Lagos.
            </p>
            <p className="mt-4 text-base text-muted-foreground">
              Every dish is freshly cooked on the day of delivery. No pre-packed shortcuts.
              Just real flames, real ingredients, real Naija love.
            </p>
            <Link to="/menu"
              className="mt-7 inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90">
              Explore the menu →
            </Link>
          </div>
          <div className="relative">
            <img src={heroJollof} alt="" className="rounded-3xl shadow-warm" />
            <div className="absolute -bottom-6 -left-6 hidden rounded-2xl bg-gold p-5 text-charcoal shadow-lg sm:block">
              <div className="font-display text-3xl font-bold">3.9★</div>
              <div className="text-xs font-semibold uppercase tracking-wide">Google rated</div>
            </div>
          </div>
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="bg-secondary/30 py-20">
        <div className="mx-auto max-w-7xl px-6">
          <GiftBanner className="mb-8" />
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="text-xs uppercase tracking-[0.25em] text-accent">Menu</div>
              <h2 className="mt-2 font-display text-4xl text-primary sm:text-5xl">A taste of everything.</h2>
            </div>
            <Link to="/menu" className="text-sm font-semibold text-primary hover:underline">View full menu →</Link>
          </div>
          <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {CATEGORIES.map((c) => (
              <Link
                key={c.id}
                to="/menu"
                hash={c.id}
                className="group relative overflow-hidden rounded-2xl shadow-soft"
              >
                <img src={c.image} alt={c.name} className="aspect-square w-full object-cover transition duration-500 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-charcoal/40 to-transparent" />
                <div className="absolute inset-x-3 bottom-3">
                  <div className="font-display text-lg text-cream">{c.name}</div>
                  <div className="text-xs text-cream/70">{c.items.length} items</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ORDER CHANNELS */}
      <section className="mx-auto max-w-7xl px-6 py-20">
        <div className="text-center">
          <div className="text-xs uppercase tracking-[0.25em] text-accent">Order now</div>
          <h2 className="mt-2 font-display text-4xl text-primary sm:text-5xl">However works for you.</h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Order directly on our site with secure card or crypto payment — or use your favourite delivery app.
          </p>
        </div>
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          <Link to="/menu"
            aria-disabled={!deliveryOpen}
            className={`group relative rounded-3xl border-2 border-primary bg-primary p-7 text-primary-foreground shadow-warm transition hover:scale-[1.02] ${!deliveryOpen ? "pointer-events-none opacity-60" : ""}`}>
            <ShoppingBag className="h-8 w-8" />
            <div className="mt-4 font-display text-2xl">Order on site</div>
            <p className="mt-1.5 text-sm opacity-90">Pay securely with Naira card, bank transfer, or crypto. Order ships only after payment is confirmed.</p>
            <div className="mt-4 text-sm font-semibold">{deliveryOpen ? "Start ordering →" : status}</div>
          </Link>
          <a href={deliveryOpen ? "https://chowdeck.com" : undefined} target="_blank" rel="noreferrer"
            aria-disabled={!deliveryOpen}
            className={`group rounded-3xl border border-border bg-card p-7 transition hover:border-accent hover:shadow-soft ${!deliveryOpen ? "pointer-events-none opacity-60" : ""}`}>
            <div className="grid h-10 w-10 place-items-center rounded-full bg-accent/15 text-accent font-bold">C</div>
            <div className="mt-4 font-display text-2xl text-primary">Chowdeck</div>
            <p className="mt-1.5 text-sm text-muted-foreground">Find us as <b>Amoke Oge</b> for fast bike delivery across Lagos.</p>
            <div className="mt-4 text-sm font-semibold text-accent">{deliveryOpen ? "Order on Chowdeck →" : status}</div>
          </a>
          <a href={deliveryOpen ? "https://glovoapp.com" : undefined} target="_blank" rel="noreferrer"
            aria-disabled={!deliveryOpen}
            className={`group rounded-3xl border border-border bg-card p-7 transition hover:border-accent hover:shadow-soft ${!deliveryOpen ? "pointer-events-none opacity-60" : ""}`}>
            <div className="grid h-10 w-10 place-items-center rounded-full bg-accent/15 text-accent font-bold">G</div>
            <div className="mt-4 font-display text-2xl text-primary">Glovo</div>
            <p className="mt-1.5 text-sm text-muted-foreground">Also available on Glovo as <b>Amoke Oge</b>. Browse and order in minutes.</p>
            <div className="mt-4 text-sm font-semibold text-accent">{deliveryOpen ? "Order on Glovo →" : status}</div>
          </a>
        </div>

      </section>

      {/* REVIEWS */}
      <section id="reviews" className="bg-charcoal py-20 text-cream">
        <div className="mx-auto max-w-7xl px-6">
          <div className="text-center">
            <div className="text-xs uppercase tracking-[0.25em] text-gold">Loved by Lagos</div>
            <h2 className="mt-2 font-display text-4xl sm:text-5xl">3.9 ★★★★ — and counting.</h2>
          </div>
          <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {REVIEWS.map((r) => (
              <figure key={r.name} className="rounded-3xl border border-cream/10 bg-cream/5 p-6">
                <div className="flex justify-start">
                  <div className="flex gap-0.5">
                    {Array.from({ length: r.stars }).map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-gold text-gold" />
                    ))}
                  </div>
                </div>
                <blockquote className="mt-4 text-sm leading-relaxed text-cream/85">"{r.text}"</blockquote>
                <figcaption className="mt-5 flex items-center gap-3 border-t border-cream/10 pt-4 text-sm">
                  <img
                    src={r.avatar}
                    alt={`${r.name} avatar`}
                    loading="lazy"
                    className="h-11 w-11 shrink-0 rounded-full ring-2 ring-gold/40"
                  />
                  <div>
                    <div className="font-semibold">{r.name}</div>
                    <div className="text-xs text-cream/60">{r.when}</div>
                  </div>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* VISIT */}
      <section id="visit" className="mx-auto max-w-7xl px-6 py-20">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <div className="text-xs uppercase tracking-[0.25em] text-accent">Visit us</div>
            <h2 className="mt-2 font-display text-4xl text-primary sm:text-5xl text-balance">
              Find us in Lekki.
            </h2>
            <div className="mt-8 space-y-5">
              <div className="flex gap-4">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-accent/15 text-accent"><MapPin className="h-5 w-5" /></div>
                <div>
                  <div className="font-semibold">Address</div>
                  <p className="text-sm text-muted-foreground">Ilasan, 30 Silverbird Rd, Eti-Osa, Lekki 105102, Lagos</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-accent/15 text-accent"><Phone className="h-5 w-5" /></div>
                <div>
                  <div className="font-semibold">Phone</div>
                  <a href="tel:+2348120633599" className="text-sm text-muted-foreground hover:text-accent">0812 063 3599</a>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-accent/15 text-accent"><Clock className="h-5 w-5" /></div>
                <div>
                  <div className="font-semibold">Hours</div>
                  <div className="text-sm text-muted-foreground">
                    <div>Sunday • 9am – 4pm</div>
                    <div>Monday – Saturday • 9am – 6pm</div>
                  </div>
                </div>
              </div>
            </div>
            <a
              href="https://waze.com/ul?q=Amoke%20Oge%20Food%20Centre%2095-59%20Moshalashi%20St%20Lagos"
              target="_blank" rel="noreferrer"
              className="mt-7 inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
            >
              Get directions on Waze →
            </a>
          </div>
          <div className="overflow-hidden rounded-3xl border border-border shadow-soft">
            <iframe
              title="Deliciousness Naija location"
              src="https://www.google.com/maps?q=30+Silverbird+Rd,+Ilasan,+Lekki,+Lagos&output=embed"
              className="h-[420px] w-full"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
            />
          </div>
        </div>
      </section>
    </>
  );
}
