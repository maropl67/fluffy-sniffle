import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2, ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Sign in — Deliciousness Naija Catering" }] }),
  component: LoginPage,
});

const ADMIN_EMAIL = "maroluv755@gmail.com";

function LoginPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);

  // Log every visit to the login page (even without signing in)
  useEffect(() => {
    fetch("/api/public/log-admin-visit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path: "/login", userId: null, email: null }),
    }).catch(() => {});
  }, []);

  async function logAttempt(success: boolean, reason: string) {
    try {
      await fetch("/api/public/log-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, success, reason }),
      });
    } catch {}
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (email.trim().toLowerCase() !== ADMIN_EMAIL) {
      await logAttempt(false, "non_admin_email");
      toast.error("This account is reserved for the site owner.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) { await logAttempt(false, error.message); throw error; }
        await logAttempt(true, "password");
        toast.success("Welcome back!");
        navigate({ to: "/admin" });
      } else {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { data: { display_name: name }, emailRedirectTo: `${window.location.origin}/admin` },
        });
        if (error) { await logAttempt(false, `signup:${error.message}`); throw error; }
        await logAttempt(true, "signup");
        toast.success("Account created — you can now sign in.");
        setMode("signin");
      }
    } catch (err: any) {
      toast.error(err?.message || "Could not authenticate");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid min-h-[80vh] place-items-center bg-secondary/30 px-4 py-16">
      <div className="w-full max-w-md rounded-3xl border border-border bg-card p-8 shadow-soft">
        <div className="flex items-center gap-2 text-accent">
          <ShieldCheck className="h-5 w-5" />
          <span className="text-xs font-semibold uppercase tracking-wider">Secure account</span>
        </div>
        <h1 className="mt-2 font-display text-3xl text-primary">
          {mode === "signin" ? "Sign in" : "Create your account"}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Restricted access — owner-only console for orders, settings & analytics.
        </p>

        <form onSubmit={submit} className="mt-6 space-y-4">
          {mode === "signup" && (
            <Field label="Name" v={name} on={setName} placeholder="Your full name" required />
          )}
          <Field label="Email" type="email" v={email} on={setEmail} required />
          <Field label="Password" type="password" v={password} on={setPassword} required />
          <button
            type="submit"
            disabled={busy}
            className="grid w-full place-items-center rounded-full bg-accent py-3 text-sm font-bold text-accent-foreground hover:bg-accent/90 disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : (mode === "signin" ? "Sign in" : "Create account")}
          </button>
        </form>

        <button
          onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
          className="mt-4 w-full text-xs text-muted-foreground hover:text-accent"
        >
          {mode === "signin" ? "New customer? Create an account" : "Already have an account? Sign in"}
        </button>

        <Link to="/" className="mt-6 block text-center text-xs text-muted-foreground hover:text-accent">← Back home</Link>
      </div>
    </div>
  );
}

function Field({ label, v, on, type = "text", placeholder, required }: {
  label: string; v: string; on: (v: string) => void; type?: string; placeholder?: string; required?: boolean;
}) {
  return (
    <label className="block">
      <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</span>
      <input
        type={type} value={v} onChange={(e) => on(e.target.value)} placeholder={placeholder} required={required}
        className="mt-1.5 block w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/30"
        autoComplete={type === "password" ? "current-password" : "on"}
      />
    </label>
  );
}
