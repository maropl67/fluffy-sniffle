import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Search, Grid, LayoutList } from "lucide-react";
import { CATEGORIES } from "@/data/menu";
import { MenuItemCard } from "@/components/site/MenuItemCard";
import { MenuGallery } from "@/components/site/MenuGallery";
import { fuzzyScore } from "@/lib/fuzzy";
import { GiftBanner } from "@/components/site/GiftBanner";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Menu — Deliciousness Naija Catering" },
      { name: "description", content: "Browse our full menu: jollof, fried rice, native soups, platters, pepper soups and more. Order online for Lagos delivery." },
    ],
  }),
  component: MenuPage,
});

type View = "menu" | "gallery";

function MenuPage() {
  const [q, setQ] = useState("");
  const [active, setActive] = useState(CATEGORIES[0].id);
  const [view, setView] = useState<View>("menu");

  useEffect(() => {
    const id = window.location.hash.replace("#", "");
    if (!id) return;
    if (id.startsWith("gallery-")) {
      setView("gallery");
      setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
    } else if (CATEGORIES.some(c => c.id === id)) {
      setActive(id);
      setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
    }
  }, []);

  // Fuzzy filter: keep whole category if its name matches; otherwise keep items that match.
  const filtered = useMemo(() => {
    const query = q.trim();
    if (!query) return CATEGORIES;
    return CATEGORIES
      .map((c) => {
        const catScore = fuzzyScore(query, c.name);
        if (catScore !== null) return { ...c, _score: catScore };
        const items = c.items
          .map((i) => {
            const s = Math.min(
              fuzzyScore(query, i.name) ?? Infinity,
              (fuzzyScore(query, i.desc) ?? Infinity) + 50,
            );
            return { i, s };
          })
          .filter((x) => Number.isFinite(x.s))
          .sort((a, b) => a.s - b.s)
          .map((x) => x.i);
        if (!items.length) return null;
        return { ...c, items, _score: 0 };
      })
      .filter(Boolean) as (typeof CATEGORIES[number] & { _score: number })[];
  }, [q]);

  return (
    <div className="bg-secondary/20">
      {/* Header */}
      <div className="bg-charcoal text-cream">
        <div className="mx-auto max-w-7xl px-6 py-12 sm:py-14">
          <div className="text-xs uppercase tracking-[0.25em] text-gold">Our menu</div>
          <h1 className="mt-2 font-display text-5xl sm:text-6xl">Eat what you love.</h1>
          <p className="mt-3 max-w-xl text-cream/75">
            Freshly cooked on the day of delivery. Add to cart, pay securely, and we'll bring the heat.
          </p>

          {/* View tabs */}
          <div className="mt-6 inline-flex rounded-full bg-cream/10 p-1 ring-1 ring-cream/20">
            <button
              type="button"
              onClick={() => setView("menu")}
              className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition ${
                view === "menu" ? "bg-gold text-charcoal" : "text-cream/80 hover:text-cream"
              }`}
            >
              <LayoutList className="h-4 w-4" /> Menu
            </button>
            <button
              type="button"
              onClick={() => setView("gallery")}
              className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition ${
                view === "gallery" ? "bg-gold text-charcoal" : "text-cream/80 hover:text-cream"
              }`}
            >
              <Grid className="h-4 w-4" /> Gallery
            </button>
          </div>

          {view === "menu" && (
            <div className="mt-5 flex max-w-md items-center gap-2 rounded-full bg-cream/10 px-4 py-2.5 ring-1 ring-cream/20 focus-within:ring-gold">
              <Search className="h-4 w-4 text-cream/60" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search — type any letter, item or category"
                className="w-full bg-transparent text-sm text-cream placeholder:text-cream/50 focus:outline-none"
              />
            </div>
          )}
        </div>
      </div>

      {view === "gallery" ? (
        <MenuGallery />
      ) : (
        <>
          {/* Sticky category nav */}
          <nav className="sticky top-[60px] z-30 border-b border-border bg-background/95 backdrop-blur">
            <div className="mx-auto max-w-7xl overflow-x-auto px-4">
              <div className="flex gap-1 py-3">
                {CATEGORIES.map((c) => (
                  <a
                    key={c.id}
                    href={`#${c.id}`}
                    onClick={() => setActive(c.id)}
                    className={`shrink-0 rounded-full px-4 py-1.5 text-xs font-semibold transition ${
                      active === c.id
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-secondary-foreground hover:bg-secondary/70"
                    }`}
                  >
                    {c.name}
                  </a>
                ))}
              </div>
            </div>
          </nav>

          {/* Menu sections */}
          <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
            <GiftBanner className="mb-8" />
            {filtered.length === 0 && (
              <p className="py-20 text-center text-muted-foreground">No items match "{q}".</p>
            )}
            {filtered.map((c) => (
              <section key={c.id} id={c.id} className="mb-14 scroll-mt-36">
                <div className="mb-5 flex items-end gap-4">
                  <img src={c.image} alt="" className="h-12 w-12 rounded-xl object-cover" />
                  <div>
                    <h2 className="font-display text-3xl text-primary">{c.name}</h2>
                    <p className="text-xs text-muted-foreground">{c.items.length} items</p>
                  </div>
                </div>
                <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                  {c.items.map((item) => (
                    <MenuItemCard key={item.id} item={item} />
                  ))}
                </div>
              </section>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
