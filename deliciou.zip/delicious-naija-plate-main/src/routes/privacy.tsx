import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy")({
  head: () => ({ meta: [{ title: "Privacy Policy — Deliciousness Naija Catering" }] }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <article className="mx-auto max-w-3xl px-6 py-16 prose-sm">
      <h1 className="font-display text-4xl text-primary">Privacy Policy</h1>
      <p className="mt-3 text-sm text-muted-foreground">Last updated: 2026</p>

      <h2 className="mt-8 font-display text-2xl text-primary">How we collect and use your data</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        We only collect the information needed to fulfil your order — your name, phone number,
        email, delivery address (when applicable) and order details. We do not sell or share
        your data with third parties for marketing.
      </p>

      <h2 className="mt-6 font-display text-2xl text-primary">Information handling</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        Your information is stored securely and accessed only by authorised staff to prepare,
        deliver and follow up on your order. We retain order records for accounting and
        regulatory purposes.
      </p>

      <h2 className="mt-6 font-display text-2xl text-primary">Payment information security</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        We never see or store your card details. Card and bank payments are processed by
        Paystack; crypto payments by NOWPayments. Both are PCI/industry-compliant providers.
      </p>

      <h2 className="mt-6 font-display text-2xl text-primary">Communication consent</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        By placing an order you consent to receive transactional emails, SMS, or voice calls
        related to that order (confirmation, ready-for-pickup, delivery follow-up). You may
        opt out of non-essential messages at any time.
      </p>
    </article>
  );
}
