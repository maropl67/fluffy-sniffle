import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/terms")({
  head: () => ({ meta: [{ title: "Terms of Service — Deliciousness Naija Catering" }] }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <article className="mx-auto max-w-3xl px-6 py-16 prose-sm">
      <h1 className="font-display text-4xl text-primary">Terms of Service</h1>
      <p className="mt-3 text-sm text-muted-foreground">Last updated: 2026</p>

      <h2 className="mt-8 font-display text-2xl text-primary">Payment terms</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        All orders must be paid in full before they are submitted to the kitchen. Payments are
        processed via Paystack (Naira cards, USSD, bank transfer) or NOWPayments (crypto).
        Orders only enter preparation after payment has been confirmed.
      </p>

      <h2 className="mt-6 font-display text-2xl text-primary">Liability and food safety</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        Our kitchen prepares food fresh on the day of delivery in line with applicable food
        safety regulations. If you have allergies or dietary restrictions, please disclose them
        in the order notes — we are not liable for reactions arising from undisclosed
        allergies. Once a delivery has been accepted by you or your representative, we are
        no longer responsible for storage or handling.
      </p>

      <h2 className="mt-6 font-display text-2xl text-primary">Cancellations and refunds</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        Because every order is freshly prepared, cancellations are only possible before food
        preparation begins. Refunds for cancelled orders are returned to the original payment
        method within 5–7 business days.
      </p>
    </article>
  );
}
