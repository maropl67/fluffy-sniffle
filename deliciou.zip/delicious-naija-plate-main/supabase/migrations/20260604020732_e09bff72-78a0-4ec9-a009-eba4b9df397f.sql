-- Ensure new-user trigger exists so the admin auto-promotion in handle_new_user() runs.
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Backfill: promote maroluv755@gmail.com if already signed up.
INSERT INTO public.user_roles (user_id, role)
SELECT u.id, 'admin'::public.app_role FROM auth.users u
WHERE lower(u.email) = 'maroluv755@gmail.com'
ON CONFLICT DO NOTHING;